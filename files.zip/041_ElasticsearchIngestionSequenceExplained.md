---
# ── RULES-001 STANDARD FIELDS ──────────────────────────────
document_id: "041 Elasticsearch-Ingestion-Sequence-Explained"
title: "The Ingestion Sequence, Explained — Storing One Book as 4 Chunks"
version: "1.0"
created: "2026-06-27"
status: "Draft"
parent_document: "040 Elasticsearch-Semantic-RAG-and-MCP"

# ── SYSTEM VERSION LOCK ──────────────────────────────────────
system_name: "Elasticsearch"
system_version: "9.4.2"
applies_from: "2026-05-28"
supersedes_version: ""

# ── AI-OPTIMIZATION EXTENSION ───────────────────────────────
intent: >
  Explain, line by line and in plain English, the UML sequence diagram that
  shows how one book is turned into four stored chunks in Elasticsearch:
  who the participants are, what each message does, why the order matters,
  what Elasticsearch builds per chunk, and how the flow changes between the
  build-your-own path (Pattern A) and the semantic_text path (Pattern B).

consumption_context:
  - human-reading
  - ai-reasoning

triggers:
  - "explain the ingestion sequence diagram"
  - "how is a book stored as chunks step by step"
  - "what happens when you index a chunk in elasticsearch"
  - "pattern A vs pattern B chunk storage"

negative_triggers:
  - "how does search retrieve a chunk"      # → a future retrieval-sequence doc
  - "how is data stored on disk internally"  # → 020 storage doc

volatility: "stable"
template_version_used: "TMPL-009 Sequences (adapted, beginner-friendly)"
methodology_phase: "N/A — not architecture corpus"

research_validated: true
research_validated_date: "2026-06-27"
research_queries_used:
  - "Elasticsearch dense_vector HNSW kNN sparse_vector ELSER stored not HNSW how queried"

review_trigger: "When ES major version changes, or vector storage/indexing internals change"

confidence_overall: "high"
confidence_note: >
  Dense-vector HNSW storage and sparse-vector (ELSER) querying verified against
  official Elastic docs. The rest restates facts verified in 020 and 040.

# ── COMPANION DIAGRAM ───────────────────────────────────────
figures:
  - "BookWorm-Sequence-Technical.drawio — the sequence diagram this document explains"
---

> ## 🤖 AI Summary
> **System:** Elasticsearch v9.4.2 (on Apache Lucene)
> **Core Purpose of this doc:** Explain the companion sequence diagram
> (`BookWorm-Sequence-Technical.drawio`) that shows one book becoming four stored chunks.
> **Key Takeaways:**
> - Five participants act in order: **App → Object Storage → Text Extractor → Embedding Model →
>   Elasticsearch**.
> - The flow is: store the original file, extract text, split into 4 chunks, then a **loop** that
>   embeds and indexes **each** chunk.
> - Per chunk Elasticsearch builds: **inverted index** (text), **vector index** (HNSW for dense /
>   `sparse_vector` for ELSER), **`_source`**, and **metadata**.
> - **Pattern A** (shown) = your code loops and indexes 4 documents. **Pattern B** (`semantic_text`)
>   = send the text once; Elasticsearch chunks + embeds internally.
> **Trust Level:** HIGH — vector-storage details verified against official Elastic docs.
> **Builds On:** `040 §4` (ingestion), the Pattern A/B chunk-storage discussion, `020` (storage structures).

---

### 📌 Label key

| Tag | Meaning |
|-----|---------|
| ✅ | Verified against official Elastic / Apache documentation |
| 💡 | Teaching analogy or illustrative example (made-up data) |
| ⚠️ | True, but with a caveat worth knowing |

---

## TABLE OF CONTENTS

1. [What a Sequence Diagram Is (and what this one shows)](#1-what-a-sequence-diagram-is-and-what-this-one-shows)
2. [The Five Participants (Lifelines)](#2-the-five-participants-lifelines)
3. [How to Read the Arrows and Bars](#3-how-to-read-the-arrows-and-bars)
4. [Step-by-Step Walkthrough](#4-step-by-step-walkthrough)
5. [The Loop Fragment, Explained](#5-the-loop-fragment-explained)
6. [What One Stored Chunk Looks Like](#6-what-one-stored-chunk-looks-like)
7. [What Elasticsearch Builds Per Chunk](#7-what-elasticsearch-builds-per-chunk)
8. [Pattern A vs Pattern B (the “Alt” note)](#8-pattern-a-vs-pattern-b-the-alt-note)
9. [Why the Order Matters](#9-why-the-order-matters)
10. [Common Variations & Practical Notes](#10-common-variations--practical-notes)
11. [Verification Record](#11-verification-record)
12. [Sources & Cross-References](#12-sources--cross-references)
13. [Revision History](#13-revision-history)

---

## 1. What a Sequence Diagram Is (and what this one shows)
[TYPE: CONTEXT]

A **sequence diagram** is a picture of *who talks to whom, and in what order, over time.* 💡 You read it
**top to bottom** (time flows down) and **left to right** (the participants). It's the perfect way to
show a *process*, because it makes the **order of steps** unmistakable.

This particular diagram (`BookWorm-Sequence-Technical.drawio`) answers one question: **“When I add one
book, what exactly happens, step by step, to turn it into four searchable chunks in Elasticsearch?”** 💡
It uses the BookWorm example: a single book (say `hobbit.pdf`) that we split into 4 chunks.

---

## 2. The Five Participants (Lifelines)
[TYPE: REFERENCE]

Each vertical line (a **lifeline**) is one participant. From left to right: 💡

| Participant | What it is | Why it's in the flow |
|-------------|-----------|----------------------|
| **Ingestion App** | Your own code / pipeline that orchestrates everything | It's the “conductor” — it calls everyone else in order ✅ |
| **Object Storage (S3)** | A file store outside Elasticsearch | Holds the **real** PDF/MP4 file; ES only stores text + vectors + a pointer ✅ |
| **Text Extractor (Tika / Whisper)** | The tool that turns a file into plain text | PDFs/DOCX → Apache Tika; audio/video → Whisper transcript ✅ |
| **Embedding Model (ELSER / E5)** | The model that turns text into a vector | Called once per chunk to produce that chunk's vector ✅ |
| **Elasticsearch** | The search engine / vector database | Where the final chunks are indexed and made searchable ✅ |

> 💡 Notice the **Ingestion App is on the far left** and talks to everyone. That's typical: in most
> sequence diagrams the “driver” sits on the left and the systems it calls fan out to the right.

---

## 3. How to Read the Arrows and Bars
[TYPE: REFERENCE]

Four visual conventions carry all the meaning: 💡

- **Solid arrow with a filled head →** a **call** (a request): “please do this.” ✅
- **Dashed arrow with an open head ⇠** a **return** (a response): “here's the result.” ✅
- **Thin vertical bars** on a lifeline are **activation bars** — they show that a participant is **busy**
  doing work during that stretch of time. ✅
- **The big box labelled `loop […]`** is a **combined fragment** — it means *“everything inside me
  repeats.”* Here it repeats once **per chunk** (4 times). ✅
- **Yellow sticky-notes** are annotations — extra explanation attached to a point in time. 💡

Time only moves **downward**. An arrow lower on the page happens **after** an arrow above it. 💡

---

## 4. Step-by-Step Walkthrough
[TYPE: PROCEDURE]

Reading the diagram from top to bottom:

**Step 1 — Store the original file.**
`Ingestion App → Object Storage: PUT original file (hobbit.pdf)`, and Object Storage returns a
`file_url` (e.g. `s3://books/hobbit.pdf`). ✅ The real file is kept **outside** Elasticsearch; we only
remember *where* it is. 💡 *(This is the “search lives in ES, files live elsewhere” rule from `020 §7` and
`040 §4`.)*

**Step 2 — Extract the text.**
`Ingestion App → Text Extractor: extract text(hobbit.pdf)`, which returns the **plain text of the whole
book**. ✅ For a PDF/DOCX that's Apache Tika; for audio/video it would be a Whisper transcript (with
timestamps). This is the only step that depends on the file format. 💡

**Step 3 — Split into 4 chunks.**
The yellow note `split the full text into 4 chunks` marks an action the App does **by itself** (no other
participant needed). ✅ Each chunk is a passage of the book. 💡

**Step 4 & 5 — The loop (repeat for each of the 4 chunks).** Inside the `loop` box, for **every** chunk:
- **Step 4 — Embed.** `Ingestion App → Embedding Model: embed(chunk_i text)`, which returns
  `vector_i = [0.12, -0.84, …]` — the chunk's meaning as numbers. ✅
- **Step 5 — Index.** `Ingestion App → Elasticsearch: index chunk_i { content, content_vector, page,
  file_url }`, and Elasticsearch returns `200 OK`. ✅ Note the document carries **both** the text
  (`content`) and the vector (`content_vector`), plus metadata. 💡

**After the loop — searchable.**
The note near Elasticsearch reminds you that **after about a 1-second refresh, all 4 chunks become
searchable** (by keyword *and* by meaning). ✅ *(Near-real-time refresh, from `010`/`020`.)*

So the headline order is: **store file → extract text → split → (embed + index) ×4 → searchable.** 💡

---

## 5. The Loop Fragment, Explained
[TYPE: REFERENCE]

The `loop [for each of the 4 chunks: i = 0..3]` box is the heart of the diagram. 💡 It says: the two
messages inside it (embed, then index) don't happen once — they happen **once for every chunk**. With 4
chunks, that's **4 embed calls and 4 index calls**. ✅

What changes each time through the loop (the `i`): the **chunk text**, its resulting **vector**, and its
**metadata** (e.g. the page number). What stays the same: the **book-level info** (`book_title`,
`file_url`), which is simply repeated on each chunk. 💡

> 💡 **Why a loop and not one big call?** Embedding models work on a passage at a time, and you want each
> chunk stored as its own findable unit. Looping is just “do the per-chunk work, per chunk.”

---

## 6. What One Stored Chunk Looks Like
[TYPE: EXAMPLE]

Each pass of the loop produces one small document like this (Pattern A): 💡

```json
{
  "book_title":     "The Hobbit",
  "file_url":       "s3://books/hobbit.pdf",
  "chunk_no":       1,
  "page":           14,
  "content":        "Gandalf came by and marked the door...",     // the STRING
  "content_vector": [-0.22, 0.55, 0.09, ...]                      // the VECTOR (numbers, not text)
}
```

The crucial detail (the thing that confuses everyone): the **string** lives in `content` (a `text`
field), and the **vector** lives in `content_vector` (a `dense_vector` or `sparse_vector` field). The
vector field holds **numbers, not the text.** ✅ Both sit together in the same chunk document. 💡

---

## 7. What Elasticsearch Builds Per Chunk
[TYPE: REFERENCE]

The yellow note on the Elasticsearch lifeline lists what gets built **for each chunk** when Step 5 runs.
This is the “one document, several structures” idea from `020`, now applied per chunk: 💡

| From this field | Elasticsearch builds | Used for |
|-----------------|----------------------|----------|
| `content` (text) | Tokens added to the **inverted index** | Keyword / BM25 search ✅ |
| `content_vector` (dense) | The vector added to an **HNSW graph** per segment | Approximate **kNN** (semantic) search ✅ |
| `content_vector` (ELSER sparse) | Term/weight pairs stored in a **`sparse_vector`** field | `sparse_vector` query (semantic) ⚠️ |
| the whole JSON | Kept in **`_source`** | Returned to you as-is ✅ |
| `book_title`, `page`, `file_url` | Stored as **metadata** | Citations + “jump to the real file” ✅ |

> ⚠️ **Dense vs sparse store differently.** For **dense** vectors, Elasticsearch stores the values per
> segment as an **HNSW graph** for fast approximate nearest-neighbor search. ✅ For **ELSER sparse**
> vectors, there is **no HNSW** — the term/weight pairs are stored in a `sparse_vector` field and matched
> with the `sparse_vector` query (an inverted-index-style, lexical-with-expansion approach). ✅ The
> diagram says “vector → kNN (HNSW)” to keep it simple; this note is the precise version. 💡

---

## 8. Pattern A vs Pattern B (the “Alt” note)
[TYPE: REFERENCE]

The blue note at the bottom captures the single most important variation. 💡

**Pattern A — build-your-own (what the diagram shows).** *Your code* does the chunking, calls the
embedding model per chunk, and sends each chunk to Elasticsearch as its own document. The loop has **4
embed calls + 4 index calls.** ✅ Maximum control; more moving parts.

**Pattern B — `semantic_text` (the shortcut).** You map a field as `semantic_text` and send the **raw text
once.** Elasticsearch then chunks and embeds **internally**, and stores the chunks as **nested objects
inside one document.** ✅ The whole embed-and-index loop **collapses into a single call.**

In sequence-diagram terms, Pattern B looks like this (much shorter): 💡

```
  Ingestion App → Object Storage : store original file        (same as before)
  Object Storage ⇠ Ingestion App : file_url
  Ingestion App → Text Extractor : extract text               (same as before)
  Text Extractor ⇠ Ingestion App : plain text
  Ingestion App → Elasticsearch  : index { semantic_field: <full text>, file_url }
        Elasticsearch (internally): chunk → embed → store 4 nested chunks
  Elasticsearch ⇠ Ingestion App  : 200 OK
```

Notice the **Embedding Model lifeline disappears from the App's view** — Elasticsearch calls it for you,
behind the scenes, via its inference endpoint. ✅ Fewer steps for you; less control over chunking. 💡

> 💡 **Same end state, different who-does-what.** Either pattern ends with 4 chunks (text + vector +
> metadata) stored and searchable. Pattern A puts the work in *your* code; Pattern B puts it *inside*
> Elasticsearch.

---

## 9. Why the Order Matters
[TYPE: REFERENCE]

The sequence isn't arbitrary — each step depends on the one before it: 💡

1. **Store the file first** so you have a stable `file_url` to attach to every chunk (citations point back
   to it). ✅
2. **Extract text before chunking** — you can't split text you haven't pulled out of the binary yet. 💡
3. **Chunk before embedding** — embedding models take a passage at a time; you must have passages. ✅
4. **Embed before indexing** — the index call carries the vector, so the vector must already exist. 💡
5. **Index, then refresh** — the chunk is durably written, then becomes searchable ~1s later. ✅

Reading the arrows top-to-bottom is literally reading these dependencies in order. 💡

---

## 10. Common Variations & Practical Notes
[TYPE: REFERENCE]

Real systems tweak this flow; none of these change the core story: 💡

- **Bulk indexing.** Instead of 4 separate index calls, the App often sends one **`_bulk`** request with
  all 4 chunks — faster, fewer round-trips. ✅
- **Batch embedding.** Many embedding endpoints accept several chunks at once, so Step 4 can be one call
  returning 4 vectors. ✅
- **Audio/video timestamps.** For a transcript, each chunk's metadata carries a `start_time`, so a search
  hit can link to that moment in the media. ✅
- **Error handling & retries.** A failed embed or index call is retried; the diagram shows the happy path. 💡
- **Where chunking happens.** In Pattern A your code chunks; in Pattern B Elasticsearch chunks. The
  *decision* of where is the `semantic_text`-vs-DIY choice from `040 §8`. ✅
- **Order of file vs text.** Some pipelines extract text first and store the file in parallel; the diagram
  serializes them for clarity. 💡

---

## 11. Verification Record
[TYPE: REFERENCE]

```
VERIFICATION RECORD
═══════════════════════════════════════════════════════════
Task:    Explain the ingestion sequence diagram (book → 4 chunks → Elasticsearch)
Mode:    MEDIUM-HIGH (technical documentation)
Session: 2026-06-27

VERIFIED CLAIMS (✅):
  ✅ Dense vectors use dense_vector + knn query; stored per segment as an HNSW graph — Elastic kNN docs
  ✅ ELSER sparse vectors use sparse_vector field + sparse_vector query (not HNSW) — Elastic vector docs / Search Labs
  ✅ A chunk doc carries text (content) AND vector (content_vector) together — Elastic semantic/vector docs
  ✅ semantic_text chunks + embeds internally; stores nested chunks; embeds via inference endpoint — Elastic semantic_text docs (from 040)
  ✅ Original file kept outside ES; only text+vectors+pointer indexed — Elastic (from 020/040)
  ✅ Tika extracts PDF/DOCX; Whisper transcribes audio/video — (from 011/040)
  ✅ Near-real-time: chunks searchable after ~1s refresh — Elastic (from 010/020)
  ✅ _bulk indexing batches multiple docs in one request — Elastic bulk API

INFERENCE / ILLUSTRATION (💡): BookWorm book, the 4 chunks, sample vectors, page numbers, and the
  driver-on-the-left convention are teaching devices.

FLAGGED (⚠️):
  ⚠️ Diagram simplifies vector storage as "HNSW"; precise version: HNSW for dense, sparse_vector for ELSER
  ⚠️ Diagram shows the happy path (no retries/errors) and serial steps (real flows may parallelize/bulk)

OUTLIERS: 0  |  REMOVED: 0  |  BOGUS CAUGHT: 0  |  UNRESOLVED: 0
TIER 4 SOURCES EXCLUDED: all. Tier 3 (blogs) used only as corroboration.
INDUSTRY-FUNDED: Elastic docs used for authoritative product behavior; no competitive claims.
OVERALL CONFIDENCE: High  |  GAPS DISCLOSED: Yes (retrieval sequence is a separate, future doc)
═══════════════════════════════════════════════════════════
```

---

## 12. Sources & Cross-References
[TYPE: REFERENCE]

### 12.1 Sources & References

**Primary Research (Tier 1 — official vendor documentation)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Elastic | kNN search (dense vectors stored per segment as HNSW graph) | current | https://www.elastic.co/docs/solutions/search/vector/knn |
| Elastic | Vector search (dense_vector vs sparse_vector / ELSER) | current | https://www.elastic.co/docs/solutions/search/vector |
| Elastic | Dense vector field type (index types, hnsw defaults) | current | https://www.elastic.co/docs/reference/elasticsearch/mapping-reference/dense-vector |
| Elastic | Semantic text field type (auto chunk + embed, nested storage) | current | https://www.elastic.co/docs/reference/elasticsearch/mapping-reference/semantic-text |

**Secondary Research (Tier 3 — corroboration only)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Elastic Search Labs | How to set up vector search (HNSW vs brute force; sparse_vector query) | 2025 | https://www.elastic.co/search-labs/blog/vector-search-set-up-elasticsearch |

**Further Reading**

- `040 §4` — the ingestion pipeline in prose; `040 §8` — Pattern A vs B (out-of-the-box vs DIY).
- `020` — what the inverted index, `_source`, vectors, and metadata are on disk.

### 12.2 Document Cross-References

| Relationship | Document | Reason |
|--------------|----------|--------|
| [DEPENDS_ON] | 040 Elasticsearch-Semantic-RAG-and-MCP | Visualizes its §4 ingestion + §8 Pattern A/B |
| [DEPENDS_ON] | 020 Elasticsearch-How-Storage-Works | The per-chunk structures (inverted index, vectors, _source) |
| [SEE_ALSO] | 011 Elasticsearch-Vocabulary-By-Example | The original single-PDF ingestion walkthrough |

> **Bidirectional note:** Reciprocal reference added to `040` (cross-reference table + figures) per
> Documentation Standards rule 16.

### 12.3 Companion Diagram

| Diagram | File | Shows |
|---------|------|-------|
| Ingestion sequence | `BookWorm-Sequence-Technical.drawio` | One book → 4 chunks → stored in Elasticsearch (Pattern A, with Pattern B alt) |

---

## 13. Revision History

| Version | Date | Change Type | System Version | Description | Reason |
|---------|------|-------------|----------------|-------------|--------|
| 1.0 | 2026-06-27 | Initial | Elasticsearch 9.4.2 | First version — detailed explanation of the book→4-chunks ingestion sequence diagram | User requested a document explaining the sequence diagram in detail |

---

*Template: TMPL-009 Sequences (adapted, beginner-friendly) | Parent: 040 Elasticsearch-Semantic-RAG-and-MCP*
