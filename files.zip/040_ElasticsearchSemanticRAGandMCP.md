---
# ── RULES-001 STANDARD FIELDS ──────────────────────────────
document_id: "040 Elasticsearch-Semantic-RAG-and-MCP"
title: "Semantic Search, RAG & the MCP Server — From Files to a Smart Chatbot"
version: "1.3"
created: "2026-06-27"
status: "Draft"
parent_document: "010 Elasticsearch-Basics"

# ── SYSTEM VERSION LOCK ──────────────────────────────────────
system_name: "Elasticsearch"
system_version: "9.4.2"
applies_from: "2026-05-28"
supersedes_version: ""

# ── AI-OPTIMIZATION EXTENSION ───────────────────────────────
intent: >
  Teach a complete beginner how Elasticsearch powers semantic search and RAG:
  how PDFs/DOCX/audio/video are ingested, what embeddings/chunks/vectors are,
  how hybrid search works, how a RAG chatbot is built, how the Elastic MCP
  server works in the latest version and how it differs from writing your own
  retrieval, out-of-the-box vs build-your-own trade-offs, the role of pipelines,
  and the many uses of semantic search beyond RAG — all via one running example.

consumption_context:
  - human-reading
  - ai-reasoning

triggers:
  - "how to build a RAG chatbot with elasticsearch"
  - "semantic search and embeddings explained"
  - "elasticsearch MCP server how it works"
  - "semantic_text vs build your own vectors"
  - "index pdf docx audio video for search"

negative_triggers:
  - "how is data stored on disk internally"   # → 020 storage doc
  - "query then fetch internals"               # → 030 retrieval doc

volatility: "evolving"
template_version_used: "TMPL-002 v1.0 (adapted for a comprehensive beginner explainer)"
methodology_phase: "N/A — not architecture corpus"

research_validated: true
research_validated_date: "2026-06-27"
research_queries_used:
  - "Elasticsearch MCP server Model Context Protocol official latest 2026"
  - "Elasticsearch ELSER inference endpoint dense_vector sparse vector semantic search 2026"
  - "Elasticsearch retrievers RRF reciprocal rank fusion hybrid search combine BM25 knn"
  - "index audio video transcription Elasticsearch speech to text Whisper semantic search"

review_trigger: "When ES major version changes, or MCP server / semantic_text features change (fast-moving area)"

confidence_overall: "high"
confidence_note: >
  Semantic/MCP features are fast-moving; verified against official Elastic docs
  and Search Labs as of 2026-06-27. Version-specific details (e.g. MCP server
  enabled by default in 9.3+) are flagged for re-check on upgrade.

# ── COMPANION FIGURES (separate SVG files) ──────────────────
figures:
  - "040_fig1_ingestion_pipeline.svg — Ingestion: any file → searchable data"
  - "040_fig2_search_modes.svg — Keyword vs semantic vs hybrid + embeddings"
  - "040_fig3_rag_and_mcp.svg — The RAG loop and where MCP fits"
  - "Elasticsearch_Master_Flowchart.svg — Master flowchart of the whole journey (see Section 12)"
  - "BookWorm-Flowchart-Technical.drawio — Editable draw.io version of the master flowchart"
---

> ## 🤖 AI Summary
> **System:** Elasticsearch v9.4.2 (+ Elastic MCP server, semantic_text, ELSER/E5, hybrid search)
> **Core Purpose:** Teach, from zero, how to turn a pile of mixed files (PDF, DOCX, audio, video)
> into a searchable knowledge base and a RAG chatbot, and explain semantic search, pipelines,
> and the MCP server along the way.
> **Key Takeaways:**
> - Every file type is converted to **text**, then **chunked**, then **embedded** into **vectors**.
> - **Semantic search** finds by *meaning* (vectors); **keyword search** finds by *exact words* (BM25);
>   **hybrid search** (RRF) combines both and is the usual production default.
> - **RAG** = retrieve the right chunks, stuff them into the LLM prompt, generate a grounded answer.
> - The **MCP server** lets an AI agent call Elasticsearch as ready-made tools; in v9.3+ it's on by default
>   for Search projects via Agent Builder.
> - **RAG is not the only use** of semantic search — recommendations, dedup, clustering, classification,
>   support routing, and agent memory all use it.
> **Trust Level:** HIGH — verified against official Elastic docs/Search Labs (fast-moving area, dated).
> **Builds On:** `010 Basics`, `011 Vocabulary`, `020 Storage`, `030 Retrieval`.
> **See figures:** `040_fig1_ingestion_pipeline.svg`, `040_fig2_search_modes.svg`, `040_fig3_rag_and_mcp.svg`.

---

### 📌 Label key

| Tag | Meaning |
|-----|---------|
| ✅ | Verified against official Elastic / Apache documentation |
| 💡 | Teaching analogy or illustrative example (made-up data) |
| ⚠️ | True, but with a caveat worth knowing |

---

## TABLE OF CONTENTS

1. [Our Running Example: the “BookWorm” Library](#1-our-running-example-the-bookworm-library)
2. [Two Ways to Search, and Why “Meaning” Matters](#2-two-ways-to-search-and-why-meaning-matters)
3. [Embeddings, Vectors, Tokens & Chunks (the heart of it)](#3-embeddings-vectors-tokens--chunks-the-heart-of-it)
4. [Getting Each File Type In: the Ingestion Pipeline](#4-getting-each-file-type-in-the-ingestion-pipeline)
5. [What a “Pipeline” Actually Is](#5-what-a-pipeline-actually-is)
6. [The Three Search Modes on BookWorm](#6-the-three-search-modes-on-bookworm)
7. [RAG: Turning Search into a Chatbot](#7-rag-turning-search-into-a-chatbot)
8. [Out-of-the-Box vs Build-Your-Own (two different axes)](#8-out-of-the-box-vs-build-your-own-two-different-axes)
9. [The MCP Server — and How It Differs from Plain Search](#9-the-mcp-server--and-how-it-differs-from-plain-search)
10. [Is RAG the Only Use of Semantic Search? (No)](#10-is-rag-the-only-use-of-semantic-search-no)
11. [The Complete BookWorm Build, End-to-End](#11-the-complete-bookworm-build-end-to-end)
12. [The Master Flowchart, Explained Step by Step](#12-the-master-flowchart-explained-step-by-step)
13. [Recommendations & Specifications](#13-recommendations--specifications)
14. [Mini-Glossary](#14-mini-glossary)
15. [Verification Record](#15-verification-record)
16. [Sources & Cross-References](#16-sources--cross-references)
17. [Revision History](#17-revision-history)

---

## 1. Our Running Example: the “BookWorm” Library
[TYPE: CONTEXT]

To keep everything concrete, we'll build one thing through the whole document: **BookWorm**, a little
personal-library assistant. You have four items, in four different formats: 💡

```
  the-hobbit.pdf        a fantasy novel              (PDF)
  cooking-basics.docx   a cookbook                   (Word document)
  history-lecture.mp4   a recorded class             (video)
  great-ideas.mp3       a podcast episode            (audio)
```

The goal: a chatbot called **“Ask BookWorm”** where you can type a plain-English question — *“How long
should I knead bread dough?”* or *“What does the lecture say about the printing press?”* — and get a
correct answer **drawn from your own files, with a citation to the source.** 💡

By the end you'll understand every layer needed to build that, and you'll see how the same machinery
powers far more than chatbots.

---

## 2. Two Ways to Search, and Why “Meaning” Matters
[TYPE: CONTEXT]

From `010`–`030` you already know **keyword search**: Elasticsearch breaks text into words (tokens),
puts them in an inverted index, and finds documents containing your words, ranked by BM25. ✅ It's fast
and exact — perfect for an ISBN, a name, or an error code.

But keyword search has a blind spot. Suppose the novel says *“a hobbit set out on an adventure,”* and a
user searches *“a small brave creature who goes on a quest.”* There are **zero shared words**, so
keyword search finds **nothing** — even though it's obviously the same idea. 💡

That gap is what **semantic search** fills: it searches by **meaning** instead of exact words. ✅
Semantic search retrieves results based on the intent and contextual meaning of a query, not literal term matching. ✅ It's how *“brave little creature”* can find *“a hobbit on an adventure.”*

> See **`040_fig2_search_modes.svg`** for a side-by-side of keyword, semantic, and hybrid search on
> exactly this query.

The catch: to search by meaning, the computer needs a way to *represent* meaning as something it can
compare. That representation is an **embedding** — the single most important new idea in this document.

---

## 3. Embeddings, Vectors, Tokens & Chunks (the heart of it)
[TYPE: REFERENCE]

### 3.1 What an embedding is

An **embedding model** is a trained AI model that reads a piece of text and outputs a long list of
numbers — a **vector** — like `[0.12, -0.84, 0.31, … ]`. ✅ The magic property: **texts with similar
meaning get vectors that sit close together** in this “number space,” even if they share no words. 💡
So *“brave little creature”* lands near *“a hobbit on an adventure,”* while *“tomato soup recipe”* lands
far away.

Searching then becomes geometry: turn the **query** into a vector too, and find the document vectors
**nearest** to it. ✅ That nearest-neighbor search over vectors is called **kNN** (k-nearest-neighbors),
and a system that stores vectors and finds nearest ones is a **vector database** — which Elasticsearch
is, when you store embeddings in `dense_vector` or `sparse_vector` fields. ✅

### 3.2 Two flavors of vectors: dense and sparse

| | **Dense vector** | **Sparse vector** |
|--|------------------|--------------------|
| Looks like | A fixed list of, say, 384 or 768 numbers, mostly non-zero | Mostly zeros; only a few “term: weight” pairs |
| Made by | Models like **E5**, OpenAI, Cohere | Elastic's **ELSER** (Elastic Learned Sparse EncodeR) |
| Field type | `dense_vector` | `sparse_vector` |
| Note | Great general meaning; multilingual options (E5) | Term-based, explainable; English; expands text into learned related terms ✅ |

ELSER is Elastic's own model that produces sparse vectors by **expanding** text into weighted related
terms (not synonyms — learned associations that capture relevance). ✅ Both flavors do semantic search;
which you pick is a tuning choice (Section 12). 💡

### 3.3 Tokens vs chunks (you already had the seed of this)

This pair confuses everyone, so here it is cleanly: 💡

- **Token** = a tiny unit, usually **one word**, produced by the analyzer. Tokens populate the
  **inverted index** and power **keyword/BM25** search. ✅ Example: *“Fire and ICE”* → `fire`, `ice`.
- **Chunk** = a **larger passage** (a few sentences or a paragraph) that a long document is split into
  **before embedding**. Each chunk becomes **one vector**, and chunks power **semantic/vector** search. ✅
  Example: a 50-page PDF → ~40 chunks of ~100–250 words each.

Why chunk at all? Two reasons: embedding models can only read so much text at once (a “context window”),
and **retrieving the one relevant paragraph beats retrieving a whole 50-page book.** ✅ Chunking is the process of breaking large documents into smaller, semantically meaningful pieces so queries match the most relevant part. ✅

> 💡 **One sentence to remember:** *tokenize for keyword search, chunk for semantic search.* Same
> document, two different ways of slicing it, for two different kinds of matching.

---

## 4. Getting Each File Type In: the Ingestion Pipeline
[TYPE: PROCEDURE]

Now the practical part you asked about: **how do a PDF, a DOCX, an audio file, and a video file each get
in?** The key realization: **they all converge to plain text, and after that they're identical.** 💡

> Follow along with **`040_fig1_ingestion_pipeline.svg`** — it shows all four formats funneling into one
> index.

### 4.1 Step 1 — get the text out (this is the only per-format part)

| File | How the text is extracted |
|------|---------------------------|
| `the-hobbit.pdf` | **Apache Tika** reads the PDF and returns its text (via Elasticsearch's attachment processor, or your own extractor). ✅ |
| `cooking-basics.docx` | **Apache Tika** again — it handles Word, PowerPoint, Excel, PDF, and many more. ✅ |
| `great-ideas.mp3` | **Speech-to-text** (e.g. OpenAI **Whisper**, AWS Transcribe, Google Speech-to-Text) turns the audio into a transcript, with timestamps. ✅ |
| `history-lecture.mp4` | Extract the audio track (e.g. with **FFmpeg**), then transcribe it with Whisper — same as audio. ✅ |

Two things to underline: 💡

- **Elasticsearch does not transcribe audio or video itself.** Transcription is an *external* step you
  run first; you then index the resulting transcript like any other text. ✅
- **Keep timestamps.** A transcript chunk can carry `start_time: 00:14:32`, so when search finds it, your
  chatbot can link the user to *that exact moment* in the lecture or podcast. ✅ *(Standard practice in
  audio/video search systems.)*

### 4.2 Step 2 — chunk the text

Each book's text is split into **chunks** (Section 3.3). A novel becomes dozens of passages; a podcast
transcript becomes one chunk per ~30 seconds of speech, etc. 💡

### 4.3 Step 3 — embed each chunk

Each chunk is sent to an **embedding model** and comes back as a **vector**. In Elasticsearch this is done
through an **inference endpoint** — a single, unified API that can point at ELSER, E5, or external
providers (OpenAI, Cohere, Bedrock, Azure, Vertex). ✅ Inference endpoints support task types like
`text_embedding`, `sparse_embedding`, `rerank`, and `completion`. ✅

### 4.4 Step 4 — store everything in one index

Each chunk becomes a small document with: the **chunk text** (→ inverted index, for keyword search), the
**vector** (→ for semantic search), the **`_source`** (the original JSON back), and **metadata**
(`book_title`, `format`, `page` or `start_time`, and a `file_url` pointing at the real file in storage). ✅

> ⚠️ **The original files stay outside Elasticsearch.** ES holds the *text* and *vectors* (to find
> things), not the actual PDF/MP4 with its fonts and audio. The real files live in object storage (e.g.
> S3); each chunk keeps a pointer back. Find the chunk in ES → fetch the real file from storage. ✅
> *(This is the same “search lives in ES, files live elsewhere” pattern from `020 §7`.)*

### 4.5 The shortcut: `semantic_text`

Elasticsearch can do steps 2–4 **for you**. If you map a field as type **`semantic_text`**, it
**automatically chunks long text and generates embeddings** at index time (and embeds your query at search
time too) using an inference endpoint. ✅ *(Official Elastic — `semantic_text` “handles chunking” and
“generates embeddings during indexing” automatically.)* You can also configure the chunking (e.g.
`strategy: word, max_chunk_size: 120, overlap: 40`). ✅ More on this “do-it-for-you vs do-it-yourself”
choice in Section 8.

---

## 5. What a “Pipeline” Actually Is
[TYPE: REFERENCE]

You've now seen the word “pipeline” a few times. It simply means **a chain of automatic steps applied to
data as it flows through.** 💡 There are two pipelines worth separating:

1. **The ingest pipeline (data going *in*).** In Elasticsearch, an **ingest pipeline** is a named series
   of **processors** that run on each document before it's stored — e.g. an `attachment` processor (Tika
   text extraction), a `set` processor (add a field), a chunk/embed step, etc. ✅ The attachment
   processor example from `011` *is* a one-step ingest pipeline. `semantic_text` quietly sets up the
   chunk-and-embed pipeline for you. ✅
2. **The RAG pipeline (a query being *answered*).** This is the bigger, app-level flow: *question →
   retrieve chunks → augment the prompt → generate an answer.* (Section 7.) 💡

So when someone says “build a pipeline and do semantic search,” they usually mean: an **ingest pipeline**
that extracts → chunks → embeds your files, plus a **retrieval/RAG pipeline** that answers questions over
them. Both are just chains of steps. 💡

---

## 6. The Three Search Modes on BookWorm
[TYPE: REFERENCE]

With everything indexed, here are the three ways to search — using real BookWorm questions. ✅
*(See `040_fig2_search_modes.svg`.)*

### 6.1 Keyword (BM25) — exact words

```http
POST /bookworm/_search
{ "query": { "match": { "content": "printing press" } } }
```
Finds chunks literally containing “printing” / “press.” Perfect for exact terms, names, codes. ✅
Misses paraphrases. 💡

### 6.2 Semantic (vector) — meaning

```http
POST /bookworm/_search
{ "retriever": { "knn": {
    "field": "content_vector", "query_vector_builder": { "text": "a small brave creature on a quest" }
} } }
```
Turns the query into a vector and finds the **nearest** chunk vectors — so it can return the Hobbit
passage with no shared words. ✅ *(Conceptual; exact syntax varies with field setup.)*

### 6.3 Hybrid (RRF) — both at once, the production default

```http
POST /bookworm/_search
{ "retriever": { "rrf": { "retrievers": [
    { "standard": { "query": { "match": { "content": "kneading dough" } } } },
    { "knn": { "field": "content_vector", "query_vector_builder": { "text": "how long to work bread dough" }, "k": 50, "num_candidates": 200 } }
] } } }
```
This runs **keyword AND semantic** in parallel and fuses their ranked lists with **Reciprocal Rank Fusion
(RRF)**. ✅ RRF ranks by the sum of `1 / (k + rank)` across the lists, rewarding documents that appear
high in *either* — and it works **without** having to reconcile the two systems' incompatible score
scales. ✅ *(Official Elastic — RRF combines BM25 and vector/ELSER results with equal weighting and
improved relevance.)*

Why hybrid usually wins: vector search alone can miss short, literal tokens (an IP, a SKU, an exact name),
while keyword search alone misses meaning. Hybrid gives you exact-term safety **and** semantic
understanding. ✅ *(Widely reported; hybrid generally beats either alone on standard relevance
benchmarks.* ⚠️ *exact gains vary by dataset.)*

> ⚠️ **Pitfall:** if you filter one sub-search (e.g. `format = "pdf"`), apply the **same filter to both**
> sub-searches, or the unfiltered one will leak results back in through the fusion. ✅

---

## 7. RAG: Turning Search into a Chatbot
[TYPE: REFERENCE]

Search gives you the right *passages*. **RAG turns those passages into a written answer.** ✅
*(Follow `040_fig3_rag_and_mcp.svg`.)* **RAG = Retrieval-Augmented Generation**, and it has three moves: 💡

1. **Retrieve.** Take the user's question, run **hybrid search** over BookWorm, get the top few chunks. ✅
2. **Augment.** Paste those chunks into the LLM's prompt as context: *“Answer the question using only the
   text below… [chunks].”* ✅
3. **Generate.** The LLM writes an answer **grounded in the supplied chunks**, and cites the source. ✅

### 7.1 A full BookWorm example

> **User:** “How long should I knead bread dough?”
> 1. **Retrieve:** hybrid search → top chunk is from `cooking-basics.docx`, page 12: *“Knead about 10
>    minutes until the dough is smooth and springs back.”*
> 2. **Augment:** that chunk (plus 2–3 more) goes into the prompt.
> 3. **Generate:** *“Knead for about 10 minutes, until the dough is smooth and springs back when poked —
>    from cooking-basics.docx, p.12.”* ✅ grounded, with a citation. 💡

Ask a **video** question — *“What did the lecture say about the printing press?”* — and the same flow
retrieves a transcript chunk from `history-lecture.mp4` at `00:14:32`, so the answer can link you to that
moment. 💡 The chatbot doesn't care which *format* the answer came from, because everything became text +
vectors back in Section 4. That's the payoff of the unified pipeline.

### 7.2 Why RAG exists (the point)

- The LLM **never read your private books**; retrieval supplies the facts it's missing. 💡
- Grounding the model in real text **reduces hallucination** (making things up). 💡
- Answers can **cite exact sources** (page, timestamp). ✅
- **Update a book → re-index → answers update.** No model retraining needed. 💡

> 💡 **RAG in one sentence:** *don't ask the model to remember your data — fetch the data and hand it to
> the model at question time.*

---

## 8. Out-of-the-Box vs Build-Your-Own (two different axes)
[TYPE: REFERENCE]

Your question mixed together two separate “out-of-the-box vs DIY” choices. They're genuinely different, so
let's pull them apart — this is one of the most useful distinctions in the whole stack. 💡

### Axis A — the semantic capability (how chunks/vectors get made)

| | **Out-of-the-box: `semantic_text`** | **Build-your-own** |
|--|--------------------------------------|---------------------|
| Chunking | Automatic ✅ | You write it (your sizes, overlap, logic) |
| Embedding | Automatic via inference endpoint ✅ | You call a model and store vectors yourself |
| Field/mapping | One `semantic_text` field ✅ | `dense_vector`/`sparse_vector` + your own ingest pipeline |
| Switching models | A mapping change ✅ | A re-embed + re-index |
| Best when | You want it working fast, sensible defaults | You need custom chunking, a specific/fine-tuned model, or full control ✅ |

The honest guidance: **start with `semantic_text`; move to build-your-own only when defaults fall short**
(non-English content, domain jargon, special chunking, data-sovereignty needs). ✅ *(Elastic's own advice:
start with `semantic_text`/ELSER; switch the inference endpoint to a dense model if results fall short —
often just a mapping change.)*

### Axis B — connecting an LLM/agent to Elasticsearch (how retrieval is wired)

| | **Out-of-the-box: the MCP server** | **Build-your-own RAG app** |
|--|-------------------------------------|----------------------------|
| Who calls ES | An AI **agent**, via ready-made MCP tools ✅ | **Your code**, calling the ES search API |
| Style | Agentic — model decides when/how to search, can iterate ✅ | One-shot retrieve → augment → generate (you control it) |
| Effort | Minimal wiring; standard protocol ✅ | You write and maintain the retrieval logic |
| Best when | Chatbots/agents, multiple tools, conversational refinement | Tight control, custom ranking, fixed flows |

**These two axes are independent.** You can use `semantic_text` (Axis A: out-of-the-box semantics) *and*
write your own RAG code (Axis B: DIY wiring). Or build your own vectors *and* expose them via the MCP
server. Mixing is normal. 💡

---

## 9. The MCP Server — and How It Differs from Plain Search
[TYPE: REFERENCE]

### 9.1 What MCP is (plain English)

**MCP = Model Context Protocol**, an open standard (originally from Anthropic) for connecting AI models to
outside tools and data. ✅ Elastic describes it as doing for AI agents what HTTP did for the web —
standardizing how agents talk to systems. ✅ The problem it solves: without a standard, every app needs
**custom code** to connect an LLM to Elasticsearch's query language; with MCP, Elasticsearch exposes its
abilities once as a standard **server**, and any MCP-compatible client can use them. ✅

### 9.2 What the Elastic MCP server actually does

It connects AI agents to your Elasticsearch data and exposes a small set of **tools** the agent can call by
itself, in natural language: ✅ *(Official Elastic / GitHub `elastic/mcp-server-elasticsearch`)*

- `list_indices` — list available indices ✅
- `get_mappings` — get a given index's field mappings ✅
- `search` — run a search with Query DSL ✅
- `get_shards` — shard information ✅

So instead of *you* writing `POST /bookworm/_search …`, the **agent** decides to call the `search` tool,
fills in the query, reads the results, and can **refine and search again** — a back-and-forth with your
data. ✅

### 9.3 How it's implemented in the latest version

- It's published as a **Docker image** (`docker.elastic.co/mcp/elasticsearch`) and an **npm package**
  (`@elastic/mcp-server-elasticsearch`), connectable over **stdio** or **streamable-HTTP**, and works with
  MCP clients like Claude Desktop, Cursor, and VS Code. ✅
- Elastic now also offers a **fully managed, hosted MCP server**, removing the need to run your own
  container — a persistent, secure gateway for any MCP host. ✅
- **Starting with version 9.3 (and serverless), the MCP server is enabled by default for Search
  projects**, exposed through **Agent Builder** (GA). ✅ *(Observability/Security users enable it via the
  AI Assistant config.)* ⚠️ *Version-gated and fast-moving — re-check against current docs on upgrade.*

### 9.4 How this DIFFERS from “the first part” (plain search / classic RAG)

This is the comparison you asked for: 💡

| | **Plain search / classic RAG (earlier docs)** | **MCP server (agentic)** |
|--|-----------------------------------------------|---------------------------|
| Who writes the query | You (Query DSL) or your RAG code | The **LLM agent**, by calling tools |
| Interaction | One-shot: retrieve → augment → generate | Iterative: search, inspect, refine, search again ✅ |
| Knows your schema? | You hard-code it | Agent can call `get_mappings`/`list_indices` to discover it ✅ |
| Can take actions / chain tools | Only what you code | Yes — combine ES with other MCP tools (export, notify) ✅ |
| Coupling | Tied to your app's code | Standard, reusable across any MCP client ✅ |

In short: **classic RAG is a fixed recipe you write; MCP makes Elasticsearch a set of tools an agent can
use conversationally.** ✅ Classic RAG is simpler and more predictable; MCP is more flexible and
“agentic.” Many systems use **both** — MCP as the retrieval tool inside an agent that still follows a
RAG-style retrieve-then-answer pattern. 💡

### 9.5 Build-your-own vs out-of-the-box MCP

If you “build your own chunk/vector/semantic capability,” you still have to **wire it to the LLM** somehow.
You can either expose it through the **standard MCP server** (out-of-the-box plumbing, instant
compatibility with any MCP client) or **write a custom integration** (more control, more code to
maintain). ✅ The out-of-the-box MCP server's advantage is **standardization and reuse**; the build-your-own
advantage is **bespoke tools and behavior** tuned to your exact app. 💡

---

## 10. Is RAG the Only Use of Semantic Search? (No)
[TYPE: REFERENCE]

RAG gets the spotlight, but semantic search / embeddings power **many** things. 💡 A tour:

- **Semantic site & product search.** “comfy shoes for standing all day” → matches by meaning, not just
  keywords. ✅
- **Recommendations / “more like this.”** Find items whose vectors are nearest to one you like. ✅
- **Deduplication & near-duplicate detection.** Two near-identical paragraphs have near-identical vectors. 💡
- **Clustering & topic discovery.** Group documents by vector proximity to see themes. 💡
- **Classification / zero-shot tagging.** Compare a document's vector to label vectors to categorize it. 💡
- **Support-ticket routing & FAQ matching.** Match an incoming ticket to the closest known issue/answer. ✅
- **Anomaly / outlier detection.** A vector far from every cluster may be unusual. 💡
- **Image, audio & multimodal search.** Embed images/audio too, and search across modalities. 💡
- **Agent memory.** Store past conversation pieces as vectors so an agent can recall relevant context
  later — Elastic explicitly markets Elasticsearch as cross-session **memory** for AI agents. ✅
- **Question answering & semantic highlighting** inside classic search apps (no LLM needed). 💡

> 💡 **Bottom line:** RAG is *one application* of a general capability — “find things by meaning.” That
> capability is reusable far beyond chatbots.

---

## 11. The Complete BookWorm Build, End-to-End
[TYPE: EXAMPLE]

Putting the whole stack together: 💡

```
  INGEST (once per file)                         ANSWER (per question)
  ─────────────────────                          ──────────────────────
  PDF  ─┐                                          User question
  DOCX ─┤→ extract text (Tika)                          │
  MP3  ─┤→ transcribe (Whisper) ──► chunk ──► embed      ▼
  MP4  ─┘   (FFmpeg+Whisper)        (passages) (vectors)  hybrid search (BM25 + vector, RRF)
                    │                                    │  over the bookworm index
                    ▼                                    ▼
            bookworm index:  text + vectors +       top chunks (+ source, page/timestamp)
            _source + metadata (title, page,             │
            timestamp, file_url)                         ▼
                                                  augment LLM prompt → generate answer + citation
                                                         │
                                                  (optionally via the MCP server, so an agent
                                                   drives the search and can refine it)
```

**Three queries, three behaviors, one system:** 💡

1. *“Find the exact line ‘once upon a time’ ”* → **keyword** wins (exact text). ✅
2. *“A story about a brave little creature on a journey”* → **semantic** wins (meaning). ✅
3. *“How do I knead dough, and which book says so?”* → **hybrid + RAG**: retrieve the cooking chunk, answer
   in words, cite `cooking-basics.docx p.12`. ✅
4. *“What did the lecture say about the printing press, and at what point?”* → retrieve the transcript
   chunk, answer, and link to `history-lecture.mp4 @ 00:14:32`. 💡

Same index, same pipeline, four formats, three search modes, one chatbot.

---

## 12. The Master Flowchart, Explained Step by Step
[TYPE: REFERENCE]

Everything in this document — and in the four documents before it — fits into **one picture**. This
section walks that picture slowly, in plain English, explaining every box, every decision diamond, and
every arrow, so you can trace any path from “a file on your laptop” to “an answer on the screen.” 💡

> **Two companion files go with this section:**
> - `Elasticsearch_Master_Flowchart.svg` — the diagram as a ready-to-view image.
> - `BookWorm-Flowchart-Technical.drawio` — the same diagram in **draw.io** format, which you can open and
>   edit at [https://app.diagrams.net](https://app.diagrams.net) (or the draw.io desktop app) to change
>   wording, colours, or add your own steps.

### 12.1 How to read the diagram (the shapes and colours)

The flowchart uses a few simple conventions — learn these five and the whole thing reads easily: 💡

- **Rounded pills** (top and bottom) are **start and end** points — where a journey begins and ends.
- **Rectangles** are **steps** — something happens to the data (extract, chunk, embed, search…).
- **Diamonds** are **decisions** — a question with two or more answers that send you down different paths.
- **The big green box** in the middle is the **Elasticsearch index** — where everything is stored.
- **Colours group the phases:** amber = *getting data in (ingest)*, green = *storing*, blue = *searching*,
  purple = *RAG / generating an answer*, indigo = *the MCP / agent path*, slate-grey = *start/end*.

The diagram is split by a **dashed line across the middle**. Everything **above** the line is **indexing**
— the one-time work of loading your files. Everything **below** the line is **searching** — what happens
every time someone asks a question. This split is the single most important thing to notice: **you build
the index once; you search it many times.** 💡

### 12.2 The top half — getting your files in (indexing)

Read top to bottom:

1. **Start: “Your files” (PDF, DOCX, MP3, MP4).** The journey begins with your raw files in mixed
   formats. 💡
2. **Decision ① — “Already plain text?”** This is the first fork, because different formats hide their
   text differently. 💡
   - **No → audio / video.** Sound isn't text, so it must be **transcribed** first with a speech-to-text
     tool (Whisper); for video you pull the audio out (FFmpeg) and then transcribe. You also keep
     **timestamps** so you can later jump to the exact moment. ✅
   - **Yes-ish → PDF / DOCX.** The words exist but are locked inside the file's binary, so **Apache Tika**
     extracts them. ✅
   - *Why this fork matters:* it's the **only** part of the whole pipeline that depends on the file
     format. Everything after it is identical for all four formats. 💡
3. **Step — “Plain text.”** Both branches now meet here. From this point on, a podcast and a PDF are
   treated exactly the same way. 💡
4. **Decision ② — “Auto-build or custom?”** Now you choose *how* the chunks and vectors get made — this is
   **Axis A** from Section 8. 💡
   - **Auto → `semantic_text`:** Elasticsearch chunks and embeds for you. Easiest start. ✅
   - **Custom → build-your-own:** you control the chunking and pick your own embedding model (ELSER, E5,
     OpenAI…) through an inference endpoint. More control, more work. ✅
   - *Either path produces the same kind of output*, which is the next box.
5. **Step — “Tokens + Chunks + Vectors ready.”** The text has been turned into the three things
   Elasticsearch needs: **tokens** (words, for keyword search), **chunks** (passages), and **vectors** (the
   meaning of each chunk, for semantic search). ✅
6. **Store — “One Elasticsearch index.”** Everything lands in a single index, which holds four structures
   (each tagged with the document that covers it):
   - **Inverted index** — tokens → which chunks contain them (powers keyword/BM25 search). ✅
   - **Vectors** — one per chunk (powers semantic/kNN search). ✅
   - **`_source`** — the original JSON, returned exactly as stored. ✅
   - **Metadata** — `title`, `page`, `timestamp`, and a `file_url` pointing at the **real file in object
     storage** (e.g. S3). ✅ *(Remember: the actual PDF/MP4 lives outside Elasticsearch; the index only
     holds text + vectors + a pointer.)*

That's the whole top half: **mixed files → plain text → chunks + vectors → one index.** Done once per file. 💡

### 12.3 The dashed divider — two different jobs

The dashed line is a reminder that the two halves run at **different times and for different reasons**: 💡
- **Above (indexing):** slow, done once when a file is added or updated. ⬆
- **Below (searching):** fast, done live every time a user asks something. ⬇

A useful mental check: if you change a book, you re-run the **top** half for that book; you never re-run it
just to answer a question. 💡

### 12.4 The bottom half — answering a question (searching)

7. **Start: “A user question arrives.”** Someone types a question into the chatbot. 💡
8. **Decision ③ — “Just FIND items, or GENERATE an answer?”** The biggest fork in the bottom half. 💡
   - **Find items →** the user just wants a *list of matching results* (like a search box). Go left.
   - **Generate an answer →** the user wants a *written answer* built from the books (a chatbot). Go right
     into RAG.
   - *Why this matters:* plain search returns documents; **RAG** returns a sentence. Same index underneath,
     different finish. 💡

**Left path — plain search:**

9. **Decision ④ — “Exact words, meaning, or both?”** Pick the search mode (Section 6). 💡
   - **Keyword (BM25)** — exact words, IDs, codes. ✅
   - **Semantic (kNN)** — meaning, synonyms, natural questions. ✅
   - **Hybrid (RRF)** — both at once, fused; the usual production default. ✅
10. **Step — “Query-then-fetch across shards.”** Whichever mode you chose, Elasticsearch runs the
    two-phase search from `030`: every shard finds and scores its top hits (query phase), the coordinator
    merges them, then fetches the `_source` for the final winners (fetch phase). ✅
11. **Step — “Ranked results.”** The user gets a ranked list, each hit carrying its source and page or
    timestamp. ✅

**Right path — RAG (the chatbot):** (this is the loop from Figure 3)

12. **Step — “1. Retrieve.”** Run a hybrid search to get the **top few chunks** most relevant to the
    question. ✅
13. **Step — “2. Augment.”** Paste those chunks into the LLM's prompt as context (“answer using only this
    text…”). ✅
14. **Step — “3. Generate.”** The LLM writes an answer **grounded** in those chunks. ✅
15. **Step — “Answer + citation.”** The answer comes back with its source — e.g. *“…from
    `cooking-basics.docx` p.12”* or *“…lecture @ 00:14:32.”* ✅

**Both paths then meet at the last decision:**

16. **Decision ⑤ — “Who drives the retrieval?”** This is **Axis B** from Section 8 — *how* the search is
    wired, independent of everything above. 💡
    - **Your app code (classic RAG):** *you* write the query; one-shot; predictable; full control. ✅
    - **MCP server (agentic):** the **AI agent** calls Elasticsearch's ready-made tools (`search`,
      `get_mappings`, …) by itself, and can search, inspect, and refine repeatedly. Enabled by default in
      v9.3+ for Search projects. ✅ ⚠️ *(version-gated — re-check on upgrade.)*
17. **End: “Results / answer delivered to the user.”** Both paths arrive here. 🎉

### 12.5 The five decisions, in one table

The whole flowchart really comes down to **five questions**. If you can answer these for your own project,
you've designed your system: 💡

| # | Decision | The two paths | Which doc covers it |
|---|----------|---------------|---------------------|
| ① | Is the file already text? | Transcribe (audio/video) vs Extract with Tika (PDF/DOCX) | `040 §4`, `011` |
| ② | Auto-build or custom? | `semantic_text` (auto) vs build-your-own vectors | `040 §8` (Axis A) |
| ③ | Find items or generate an answer? | Plain search vs RAG | `040 §6–7` |
| ④ | Exact words, meaning, or both? | Keyword vs semantic vs hybrid | `040 §6`, `030` |
| ⑤ | Who drives retrieval? | Your code vs MCP server | `040 §8–9` (Axis B) |

### 12.6 Three example journeys through the chart

Tracing real questions makes the paths click: 💡

- **“Find the exact phrase ‘once upon a time’.”**
  `start → ③ find items → ④ exact → Keyword (BM25) → query-then-fetch → ranked results → end.` 💡
- **“A story about a brave little creature on a journey” (chatbot answer).**
  `start → ③ generate answer → Retrieve (hybrid) → Augment → Generate → Answer + citation (the-hobbit.pdf) → ⑤ → end.` 💡
- **“What did the lecture say about the printing press, asked through an AI agent?”**
  `start → ③ generate answer → Retrieve (hybrid over the transcript) → Augment → Generate → Answer + citation (lecture @ 00:14:32) → ⑤ MCP server → end.` 💡

Same diagram, three completely different journeys — which is exactly why a single flowchart can capture the
whole stack. 💡

---

## 13. Recommendations & Specifications
[TYPE: REFERENCE]

Practical, opinionated guidance for building this for real: 💡

- **Default to hybrid search (RRF).** It's the most reliable relevance for mixed questions; pure-vector
  alone tends to miss exact terms. ✅
- **Start with `semantic_text` + ELSER (English) or E5 (multilingual).** Move to a custom dense model only
  if relevance falls short on your domain/jargon — often just a mapping change. ✅
- **Chunk sizes:** a few hundred words with some overlap is a sensible start (e.g. `max_chunk_size` ~120–250
  words, `overlap` ~10–20%); tune by testing. 💡 ⚠️ Too-big chunks dilute meaning; too-small chunks lose
  context.
- **Always store metadata per chunk:** `book_title`, `format`, `page`/`start_time`, `file_url`. It's what
  makes citations and “jump to source” possible. 💡
- **Keep the original files in object storage** (S3/GCS/Azure), not in Elasticsearch; store a pointer. ✅
- **Apply the same filters to every sub-search** in a hybrid query (permissions, language, format). ✅
- **Consider a reranker** (a cross-encoder, via a `rerank` inference task) as an optional second stage to
  reorder the top candidates for extra precision. ✅
- **Measure relevance**, don't guess: use the `rank_eval` API with a small judged query set before/after
  changes. ✅
- **Mind the ELSER 512-token limit per field** — long fields get truncated for semantic matching unless
  chunked. ✅
- **For audio/video**, transcribe first (Whisper/Transcribe), keep word-level timestamps, and consider
  speaker labels (diarization) for podcasts/meetings. ✅
- **Security:** the MCP server can be restricted (e.g. hide write/delete tools); store credentials in
  environment/secret stores, use HTTPS, and scope access. ✅

---

## 14. Mini-Glossary
[TYPE: REFERENCE]

- **Embedding / vector** — a list of numbers representing a text's meaning; near = similar. ✅
- **Token** — one word unit for keyword (BM25) search. ✅
- **Chunk** — a passage of text that becomes one embedding for semantic search. ✅
- **Dense vs sparse vector** — fixed list of numbers (E5/OpenAI) vs mostly-zero term/weight pairs (ELSER). ✅
- **ELSER / E5** — Elastic's sparse model / a multilingual dense model. ✅
- **Inference endpoint** — Elasticsearch's unified API to call an embedding/rerank/LLM model. ✅
- **`semantic_text`** — a field type that auto-chunks and auto-embeds. ✅
- **kNN** — nearest-vector search. ✅
- **Hybrid search / RRF** — combine keyword + vector results by rank fusion. ✅
- **RAG** — retrieve relevant chunks, augment the prompt, generate a grounded answer. ✅
- **Ingest pipeline** — chain of processors run on data as it's indexed. ✅
- **MCP** — open protocol letting AI agents call tools/data (e.g. Elasticsearch) in a standard way. ✅
- **Agent Builder** — Elastic's GA feature that exposes Elasticsearch to agents via MCP. ✅

---

## 15. Verification Record
[TYPE: REFERENCE]

```
VERIFICATION RECORD
═══════════════════════════════════════════════════════════
Task:    Comprehensive explainer — semantic search, RAG, multi-format ingest, MCP, use cases
Mode:    MEDIUM-HIGH (technical documentation; fast-moving features, dated)
Session: 2026-06-27

VERIFIED CLAIMS (✅):
  ✅ Semantic search retrieves by meaning/intent, not literal terms — Elastic ELSER docs
  ✅ Embeddings = vectors; similar meaning → nearby vectors; ES is a vector DB (dense/sparse) — Elastic vector docs
  ✅ ELSER = Elastic sparse model (English, term expansion); E5 = multilingual dense — Elastic docs
  ✅ Inference endpoints unify model access; tasks: text_embedding/sparse_embedding/rerank/completion — Elastic
  ✅ semantic_text auto-chunks + auto-embeds at index & query time; chunking configurable — Elastic semantic_text docs
  ✅ Chunking = split long docs before embedding for better retrieval — Elastic Search Labs
  ✅ Attachment processor (Tika) extracts PDF/DOCX/etc.; ingest pipeline = chain of processors — Elastic docs (from 011)
  ✅ Audio/video need external speech-to-text (Whisper/Transcribe); ES does not transcribe — multiple sources
  ✅ Hybrid search via rrf retriever fuses BM25 + vector/ELSER; RRF = Σ 1/(k+rank); no score reconciliation — Elastic RRF docs
  ✅ Apply same filters to both sub-searches in hybrid — corroborated practice
  ✅ MCP = open protocol (Anthropic) standardizing agent↔tool/data; "HTTP for AI agents" — Elastic what-is/mcp
  ✅ Elastic MCP server tools: list_indices, get_mappings, search, get_shards — Elastic / GitHub elastic/mcp-server-elasticsearch
  ✅ Distributed as Docker image + npm @elastic/mcp-server-elasticsearch; stdio/streamable-HTTP; Claude Desktop etc. — GitHub/Elastic
  ✅ Fully managed hosted MCP server now offered — Elastic what-is/mcp
  ✅ MCP server enabled by default for Search projects in v9.3+ and serverless, via Agent Builder (GA) — Elastic what-is/mcp
  ✅ MCP enables iterative/agentic, multi-tool workflows vs one-shot classic RAG — Elastic Search Labs / what-is/mcp
  ✅ ELSER considers only first ~512 tokens per field — Elastic ELSER docs
  ✅ Elasticsearch marketed as cross-session memory for AI agents — Elastic Search Labs

INFERENCE / ILLUSTRATION (💡): the BookWorm files, queries, kneading answer, timestamps, chunk-size
  suggestions, and use-case list framing are teaching devices, not benchmarks.

FLAGGED (⚠️):
  ⚠️ "Hybrid beats either alone" is generally true but gains vary by dataset (Tier 2/3 benchmark claims)
  ⚠️ MCP-server default-on (9.3+) is version-gated and fast-moving — re-verify on upgrade
  ⚠️ Exact query syntax for knn/semantic_text/retrievers varies with field/version setup

OUTLIERS: 0  |  REMOVED: 0  |  BOGUS CAUGHT: 0  |  UNRESOLVED: 0
TIER 4 SOURCES EXCLUDED: all (none used). Tier 3 (Medium/blogs) used only as corroboration.
INDUSTRY-FUNDED: Elastic docs used for authoritative product behavior; no competitive benchmark claims relied on.
OVERALL CONFIDENCE: High (with dated caveat on MCP/semantic features)  |  GAPS DISCLOSED: Yes
═══════════════════════════════════════════════════════════
```

---

## 16. Sources & Cross-References
[TYPE: REFERENCE]

### 16.1 Sources & References

**Primary Research (Tier 1 — official vendor documentation)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Elastic | What is the Model Context Protocol (MCP)? (hosted server; 9.3+ default; Agent Builder) | current | https://www.elastic.co/what-is/mcp |
| Elastic (GitHub) | elastic/mcp-server-elasticsearch (tools, Docker/npm, transports) | 2026 | https://github.com/elastic/mcp-server-elasticsearch |
| Elastic | Vector search in Elasticsearch (dense/sparse, ELSER, E5, chunking) | current | https://www.elastic.co/docs/solutions/search/vector |
| Elastic | Semantic text field type (auto chunk + embed) | current | https://www.elastic.co/docs/reference/elasticsearch/mapping-reference/semantic-text |
| Elastic | ELSER (sparse encoder; 512-token note) | current | https://www.elastic.co/docs/explore-analyze/machine-learning/nlp/ml-nlp-elser |
| Elastic | Reciprocal rank fusion (rrf retriever) | current | https://www.elastic.co/docs/reference/elasticsearch/rest-apis/reciprocal-rank-fusion |
| Elastic Search Labs | Using the Elasticsearch MCP server | 2026 | https://www.elastic.co/search-labs/blog/model-context-protocol-elasticsearch |
| Elastic Search Labs | Chunking strategies in Elasticsearch | 2025 | https://www.elastic.co/search-labs/blog/chunking-strategies-elasticsearch |

**Secondary Research (Tier 3 — corroboration only, flagged where used)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Medium (various) | Whisper/FFmpeg audio & video → transcription → semantic search | 2024–2025 | (multiple; audio/video transcription pattern) |
| Medium | Hybrid search: BM25 + HNSW + RRF for RAG | 2026 | https://ashutoshkumars1ngh.medium.com/hybrid-search-done-right-fixing-rag-retrieval-failures-using-bm25-hnsw-reciprocal-rank-fusion-a73596652d22 |

**Further Reading**

- Elastic docs — “Semantic search with semantic_text” end-to-end tutorial.
- Elastic docs — “Retrievers” framework and “kNN search.”
- Model Context Protocol — modelcontextprotocol.io (the open spec).

### 16.2 Document Cross-References

| Relationship | Document | Reason |
|--------------|----------|--------|
| [DEPENDS_ON] | 010 Elasticsearch-Basics | Builds on cluster/index/shard, inverted index, BM25 |
| [DEPENDS_ON] | 020 Elasticsearch-How-Storage-Works | Uses chunks/vectors/_source storage and the “files live elsewhere” pattern |
| [DEPENDS_ON] | 030 Elasticsearch-How-Retrieval-Works | Hybrid search builds on query-then-fetch + BM25 scoring |
| [SEE_ALSO] | 011 Elasticsearch-Vocabulary-By-Example | The PDF-ingestion walkthrough this generalizes to 4 formats |
| [EXTENDED_BY] → | 041 Elasticsearch-Ingestion-Sequence-Explained | Step-by-step sequence diagram of §4 ingestion (book → 4 chunks) |
| [EXTENDED_BY] → | 042 Elasticsearch-HLLFD-Explained | High-level logical flow diagrams for storing and retrieval |

> **Bidirectional note:** Reciprocal references added to `010`, `020`, and `030` per Documentation
> Standards rule 16. A `000` master index can now tie 010/011/020/030/040 together.

### 16.3 Companion Figures (separate files)

| Figure | File | Shows |
|--------|------|-------|
| 1 | `040_fig1_ingestion_pipeline.svg` | Any file (PDF/DOCX/audio/video) → text → chunks → vectors → one index |
| 2 | `040_fig2_search_modes.svg` | Keyword vs semantic vs hybrid; what an embedding is |
| 3 | `040_fig3_rag_and_mcp.svg` | The RAG loop (retrieve→augment→generate) and where MCP fits |
| 4 | `Elasticsearch_Master_Flowchart.svg` | **Master flowchart** — full journey: files → index → search/RAG → MCP (explained in Section 12) |
| 4d | `BookWorm-Flowchart-Technical.drawio` | The master flowchart in editable **draw.io** format (open at app.diagrams.net) |
| 5 | `BookWorm-Sequence-Technical.drawio` | **Sequence diagram** — storing one book as 4 chunks (explained in doc `041`) |
| 6 | `BookWorm-HLLFD-Storing-Technical.drawio` | **HLLFD — Storing**: inputs → pipeline → index (explained in doc `042`) |
| 7 | `BookWorm-HLLFD-Retrieval-Technical.drawio` | **HLLFD — Retrieval**: question → search + RAG → answer (explained in doc `042`) |

---

## 17. Revision History

| Version | Date | Change Type | System Version | Description | Reason |
|---------|------|-------------|----------------|-------------|--------|
| 1.0 | 2026-06-27 | Initial | Elasticsearch 9.4.2 | First version — semantic search, RAG, multi-format ingest, MCP server, OOTB vs DIY, use cases, with 3 companion figures | User requested an in-depth, beginner-friendly, well-rounded treatment of RAG + semantic + MCP + pipelines via a real multi-format example |
| 1.1 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Added Section 12 (Master Flowchart, Explained Step by Step); renumbered later sections; added master flowchart SVG + editable draw.io companion files | User asked for a detailed flowchart walkthrough plus a draw.io version of the diagram |
| 1.2 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Registered new child doc 041 (ingestion-sequence explainer) and the BookWorm sequence draw.io diagram in cross-references + figures | Sequence diagram and its explainer authored; reciprocal references required by rule 16 |
| 1.3 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Registered new child doc 042 (HLLFD explainer) and the two HLLFD draw.io diagrams (storing + retrieval) in cross-references + figures | HLLFD diagrams and explainer authored; reciprocal references required by rule 16 |

---

*Template: TMPL-002 Technical Reference v1.0 (adapted for a comprehensive beginner explainer) | Parent: 010 Elasticsearch-Basics*
