---
# ── RULES-001 STANDARD FIELDS ──────────────────────────────
document_id: "030 Elasticsearch-How-Retrieval-Works"
title: "How Retrieval Works — From a Query to Ranked Results"
version: "1.1"
created: "2026-06-27"
status: "Draft"
parent_document: "010 Elasticsearch-Basics"

# ── SYSTEM VERSION LOCK ──────────────────────────────────────
system_name: "Elasticsearch"
system_version: "9.4.2"
applies_from: "2026-05-28"
supersedes_version: ""

# ── AI-OPTIMIZATION EXTENSION ───────────────────────────────
intent: >
  Explain in plain English how Elasticsearch turns a search request into a
  ranked list of results: the two-phase query-then-fetch model, query-time
  analysis, reading the inverted index, BM25 scoring, query vs filter
  context, which structure each query type reads, and pagination limits.

consumption_context:
  - human-reading
  - ai-reasoning

triggers:
  - "how does elasticsearch search work"
  - "query then fetch explained"
  - "how does BM25 scoring work in elasticsearch"
  - "query context vs filter context"
  - "elasticsearch deep pagination search_after"

negative_triggers:
  - "elasticsearch mapping field types reference"   # → storage doc / API ref
  - "how is data stored on disk"                      # → 020 storage doc

volatility: "stable"
template_version_used: "TMPL-002 v1.0 (adapted for an in-depth explainer)"
methodology_phase: "N/A — not architecture corpus"

research_validated: true
research_validated_date: "2026-06-27"
research_queries_used:
  - "Elasticsearch search query phase fetch phase coordinating node distributed search"
  - "Elasticsearch query context filter context relevance _score filter cache"
  - "Elasticsearch from size max_result_window search_after point in time pagination"

review_trigger: "When system_version major number changes, or search execution model changes materially"

confidence_overall: "high"
confidence_note: >
  Query-then-fetch, query/filter context, BM25 components, and pagination
  limits verified against official Elastic documentation. The core search
  execution model is stable across recent versions.
---

> ## 🤖 AI Summary
> **System:** Elasticsearch v9.4.2 (on Apache Lucene)
> **Core Purpose of this doc:** Explain how a query becomes ranked results.
> **Key Takeaways:**
> - Search runs in **two phases**: a **query phase** (every shard finds + scores its top hits, returns
>   only ids + scores) and a **fetch phase** (the coordinating node pulls the real `_source` for the
>   final top N). This is **"query-then-fetch."**
> - The query text is **analyzed with the same analyzer used at index time**, then looked up in the
>   **inverted index**; matches are scored by **BM25** (term rarity + frequency + field length).
> - **Query context** computes a relevance `_score`; **filter context** is a cacheable yes/no with no score.
> - `from`/`size` paging is capped at **10,000** by default; deeper paging uses **`search_after`** (+ PIT).
> **Trust Level:** HIGH — verified against official Elastic docs.
> **Builds On:** `010 Basics`, `011 Vocabulary-By-Example`, `020 How Storage Works`.

---

### 📌 Label key

| Tag | Meaning |
|-----|---------|
| ✅ | Verified against official Elastic / Apache Lucene documentation |
| 💡 | Teaching analogy or inference built on verified facts |
| ⚠️ | True, but with a caveat worth knowing |

---

## TABLE OF CONTENTS

1. [Retrieval = Reading the Structures Storage Built](#1-retrieval--reading-the-structures-storage-built)
2. [The Two-Phase Search: Query-Then-Fetch](#2-the-two-phase-search-query-then-fetch)
3. [Step 0: Query-Time Analysis](#3-step-0-query-time-analysis)
4. [Reading the Inverted Index](#4-reading-the-inverted-index)
5. [Scoring with BM25](#5-scoring-with-bm25)
6. [Query Context vs Filter Context](#6-query-context-vs-filter-context)
7. [Which Query Reads Which Structure](#7-which-query-reads-which-structure)
8. [Pagination & Result Windows](#8-pagination--result-windows)
9. [The Résumé Example, End-to-End](#9-the-résumé-example-end-to-end)
10. [One-Page Summary](#10-one-page-summary)
11. [Verification Record](#11-verification-record)
12. [Sources & Cross-References](#12-sources--cross-references)
13. [Revision History](#13-revision-history)

---

## 1. Retrieval = Reading the Structures Storage Built
[TYPE: CONTEXT]

`020` showed that one document is written into several structures. **Retrieval is simply reading the
right structure for the question being asked.** 💡

| The question | Structure read (from `020`) |
|--------------|------------------------------|
| "Which docs contain this word?" | Inverted index (`.tim/.doc/.pos`) ✅ |
| "How relevant is each match?" | Term freq + length norms in the index → BM25 ✅ |
| "Is this number/date in range?" | Points / BKD tree (`.kdd`) ✅ |
| "Sort / group by this field" | Doc values (`.dvd`) ✅ |
| "Find semantically similar text" | Vectors (HNSW) ✅ |
| "Give me the actual document back" | `_source` stored fields (`.fdt`) ✅ |

Everything below is how Elasticsearch coordinates those reads across a distributed cluster and
turns them into a single ranked page of results. 💡

---

## 2. The Two-Phase Search: Query-Then-Fetch
[TYPE: REFERENCE]

A search usually has to touch **every shard** of an index, because any shard could hold a match. ✅
To do that efficiently, Elasticsearch uses a default two-phase model called **query-then-fetch.** ✅
*(Official Elastic — distributed search.)*

```
                         ┌─────────────── COORDINATING NODE ───────────────┐
  Client ──search──►     │ (the node that received the request)            │
                         │                                                 │
        QUERY PHASE      │  broadcast query to a copy of EVERY shard ──────┼──► shard 0 ─┐
                         │                                                 │    shard 1 ─┤ each shard
                         │  each shard runs the query LOCALLY, builds a    │    shard 2 ─┘ runs locally
                         │  priority queue of (from+size) top hits, returns│
                         │  only DOC IDs + SCORES (not the documents) ◄────┼──── ids+scores
                         │  coordinator MERGES them into one global ranking│
                         │                                                 │
        FETCH PHASE      │  ask only the shards holding the final top N    │
                         │  for the real documents (_source, highlights) ──┼──► multi-GET
                         │  assemble the single response ◄─────────────────┼──── _source
  Client ◄──results──    └─────────────────────────────────────────────────┘
```

The two phases, precisely: ✅

- **Query phase.** The coordinating node forwards the request to a **primary or replica copy of every
  shard**. Each shard executes the query locally and builds a **local priority queue of size
  `from + size`**, then returns just the **doc IDs and scores** (and sort values) — not the documents.
  The coordinating node **merges** these into a globally sorted list. ✅
- **Fetch phase.** The coordinating node now knows the final winners. It issues a **multi-GET** to the
  shards holding those documents, which load the **`_source`** bodies (plus highlighting/metadata if
  requested), and the coordinator assembles the final response. ✅

> 💡 **Why two phases?** Moving full documents from every shard would be wasteful. So phase 1 moves
> only lightweight ids+scores to decide the winners; phase 2 fetches full bodies for *only* the
> handful that made the final page. Find first, fetch last.

A note on where the work happens: **shards do the matching and scoring** (each shard is a Lucene
index from `020`); the **coordinating node does the merging and final assembly.** ✅ Replicas count
here too — a search can be served by either a primary or a replica shard, which is how replicas add
read capacity (from `010`). ✅

---

## 3. Step 0: Query-Time Analysis
[TYPE: REFERENCE]

Before anything is looked up, the **text in your query is analyzed by the same analyzer that was used
when indexing that field.** ✅ *(Official Elastic — query-time analysis mirrors index-time analysis.)*

```
  index time:  "Alice — PYTHON Developer"  → [alice, python, developer]
  query time:  "Python"                     → [python]      ← same lowercase/tokenize rules
                                                   │
                                                   ▼ now they can match
```

This symmetry is the whole reason matching works. 💡 If the query were lowercased but the index were
not (or vice-versa), `python` would never line up with `Python`. Using a *different* analyzer at
search time is possible but is exactly how people accidentally get "no results" for text that is
clearly there. ⚠️

---

## 4. Reading the Inverted Index
[TYPE: REFERENCE]

Once the query terms exist, each shard reads its inverted index (from `020`): 💡

1. **Look up each term** in the sorted term dictionary (`.tim/.tip`). ✅
2. **Pull its postings list** (`.doc`) — the doc IDs that contain the term (plus frequencies; plus
   positions from `.pos` if it's a phrase query). ✅
3. **Combine** postings according to the query's boolean logic: 💡

```
  python  → {doc1, doc3}
  toronto → {doc1, doc3}

  match "python"            → {doc1, doc3}            (union of one term)
  "python" AND "toronto"    → {doc1, doc3}            (intersection)
  "python" AND NOT "berlin" → {doc1, doc3} \ {doc2}   (difference)
```

This is the same back-of-book lookup from `010` — no document is scanned, the index is read
directly. ✅ Phrase queries (`"data scientist"`) additionally check that the terms appear in
**adjacent positions**, which is why positions are stored. ✅

---

## 5. Scoring with BM25
[TYPE: REFERENCE]

Matching tells you *which* documents qualify; **scoring** decides *the order*. Elasticsearch sorts
results by a relevance `_score` by default. The relevance score is a positive floating-point number returned in the `_score` field; the higher the score, the more relevant the document. ✅ The default algorithm is **BM25**, which blends three intuitions: ✅ *(Official Elastic — BM25 similarity.)*

| Ingredient | Plain meaning | Effect on score |
|-----------|---------------|-----------------|
| **TF** — term frequency | How often the term appears in this document | More = higher, but with **diminishing returns** (saturates; controlled by `k1`, default 1.2) ✅ |
| **IDF** — inverse document frequency | How **rare** the term is across all documents | Rare words (e.g. "pandas") count for more than common ones (e.g. "the") ✅ |
| **Field-length norm** | How long the field is | A hit in a short field outweighs the same hit in a very long one (controlled by `b`, default 0.75) ✅ |

So a match on a **rare** word, appearing a **few** times, in a **short** field, scores highest. 💡
The raw material for all three (term frequencies and length norms) was written into the index at
storage time — scoring just reads it. ✅

> ⚠️ **Distributed-scoring gotcha.** Elasticsearch computes **IDF per shard**, not across the whole
> index — each shard only sees its own documents when judging how "rare" a term is. ✅ With evenly
> distributed data this is fine, but it can make the *same* document score slightly differently
> depending on its shard. To force globally consistent term statistics, use
> `search_type=dfs_query_then_fetch`, which runs a small **pre-query** to gather global term stats
> before scoring. ✅ *(Elastic — the "dfs" search types fetch term frequencies from all shards first.)*

---

## 6. Query Context vs Filter Context
[TYPE: REFERENCE]

Every clause runs in one of two "contexts," and the difference matters for both relevance and speed. ✅
*(Official Elastic — query and filter context.)*

| | **Query context** | **Filter context** |
|--|-------------------|---------------------|
| Question it answers | "*How well* does this match?" | "*Does* this match? yes/no" |
| Produces a `_score`? | Yes ✅ | No — just include/exclude ✅ |
| Cacheable? | Not in the same way | **Yes** — frequent filters are cached ✅ |
| Best for | Full-text relevance (`match`) | Exact values, ranges, permissions (`term`, `range`) ✅ |

A real query usually combines both, via a `bool` query: 💡

```http
POST /resumes/_search
{ "query": { "bool": {
    "must":   { "match": { "content": "python" } },   ← query context: scores relevance
    "filter": [ { "term":  { "location": "Toronto" } } ] ← filter context: yes/no, cached
} } }
```

The `must` clause scores how well each résumé matches "python"; the `filter` clause just keeps the
Toronto ones, adds nothing to the score, and gets cached for next time. ✅ Moving exact conditions
into `filter` is one of the simplest ways to make searches faster. 💡

---

## 7. Which Query Reads Which Structure
[TYPE: REFERENCE]

A useful way to tie retrieval back to storage: each query type is really "read this structure." ✅

| Query type | What it does | Structure it reads (from `020`) |
|-----------|--------------|----------------------------------|
| `match` | Full-text, analyzed, relevance-ranked | Inverted index + BM25 ✅ |
| `term` | Exact value, no analysis | Inverted index (keyword term) ✅ |
| `match_phrase` | Words adjacent and in order | Inverted index **positions** (`.pos`) ✅ |
| `range` | Numbers/dates within bounds | Points / BKD tree (`.kdd`) ✅ |
| `sort` / aggregations | Order or summarize by a field | Doc values (`.dvd`) ✅ |
| `knn` / `semantic` | Nearest vectors (meaning) | Vector index (HNSW) ✅ |

Notice **keyword/range/sort clauses don't need relevance** — they belong in filter context and are
exactly the ones Elasticsearch caches. 💡

---

## 8. Pagination & Result Windows
[TYPE: REFERENCE]

By default a search returns the top **10** hits; you page with **`from`** (skip) and **`size`**
(count). ✅ But there's a hard limit you will eventually hit: **`from + size` cannot exceed 10,000**
by default — a safeguard set by `index.max_result_window`. ✅ *(Official Elastic — paginate search
results.)*

Why the cap exists ties straight back to Section 2: 💡

```
  Request from=10000, size=10, across 5 shards:
   → EACH shard must build a priority queue of 10,010 hits
   → coordinator must merge & sort 5 × 10,010 ≈ 50,050 hits
   → just to return 10 of them   →  heavy CPU/memory, can destabilize the cluster ✅
```

So for going deep, don't raise the cap — use the right tool: ✅

- **`search_after`** — stateless "next page" using the **sort values of the last hit** as a bookmark
  (always include a unique tie-breaker like `_id`). Efficient at any depth. ✅
- **Point in Time (PIT)** — a lightweight snapshot of the index; combine with `search_after` for
  **consistent** paging even while data changes underneath. ✅
- **`scroll`** — older bulk-export cursor; no longer recommended for deep user-facing pagination. ✅

> 💡 **Rule of thumb:** real users rarely page past a few screens; if you "need" page 5,000, the
> query is usually too broad. Deep pagination is for *exports/reindexing*, and that's what
> `search_after`+PIT are for.

---

## 9. The Résumé Example, End-to-End
[TYPE: EXAMPLE]

Putting it all together with the three résumés from `011` (Alice = Python/Toronto, Bob = Java/Berlin,
Carol = Python+pandas/Toronto), running **"who knows python?"**: 💡

```
 1. POST /resumes/_search { "query": { "match": { "content": "python" } } }
        │
 2. COORDINATING NODE broadcasts to every shard of "resumes"        (Section 2)
        │
 3. Each shard:  analyze "python" → [python]                        (Section 3)
                 look up "python" in its inverted index → {Alice, Carol}   (Section 4)
                 score with BM25 (Carol mentions python + pandas → slightly higher)  (Section 5)
                 return ids + scores  →  Carol:0.61, Alice:0.58     (Bob: no match)
        │
 4. COORDINATING NODE merges shard results → global order: Carol, Alice
        │
 5. FETCH PHASE: pull _source for Carol & Alice from their shards   (Section 2)
        │
 6. Return ranked hits with _score and _source to the client
```

Add a filter — *"python people, but only in Toronto"* — and step 3 also yes/no-checks the cached
`location: Toronto` filter (both still qualify), with no effect on the score. ✅ *(Section 6.)*

---

## 10. One-Page Summary
[TYPE: REFERENCE]

```
  SEARCH REQUEST
        │
        ▼  (coordinating node)
  ┌──────────────────────── QUERY PHASE (every shard, in parallel) ───────────────────────┐
  │  analyze query text  →  look up terms in inverted index  →  combine (AND/OR/NOT)       │
  │  score matches with BM25 (TF · IDF · length norm)  →  local top (from+size) ids+scores │
  └───────────────────────────────────────────────────────────────────────────────────────┘
        │  merge all shards → one globally ranked list
        ▼
  ┌──────────────────────── FETCH PHASE ────────────────────────┐
  │  pull _source (+ highlights) for the final top N only        │
  └──────────────────────────────────────────────────────────────┘
        │
        ▼
  RANKED RESULTS  (each hit: _score + _source)

  query context = scored (match)        filter context = yes/no, cached (term, range)
  paging: from/size ≤ 10,000  →  beyond that use search_after (+ PIT)
```

---

## 11. Verification Record
[TYPE: REFERENCE]

```
VERIFICATION RECORD
═══════════════════════════════════════════════════════════
Task:    In-depth retrieval explainer (query-then-fetch, analysis, BM25, contexts, pagination)
Mode:    MEDIUM-HIGH (technical documentation, deep internals)
Session: 2026-06-27

VERIFIED CLAIMS (✅):
  ✅ Search is two-phase: query-then-fetch (default) — Elastic distributed search docs
  ✅ Coordinating node broadcasts to a copy of every shard; query phase returns ids+scores — Elastic
  ✅ Each shard builds a priority queue of size from+size; coordinator merges globally — Elastic
  ✅ Fetch phase loads _source (+highlighting) for final top N via multi-GET — Elastic
  ✅ Query-time analysis uses the same analyzer as index time — Elastic
  ✅ _score is a positive float; default sort is by relevance — Elastic query/filter context docs
  ✅ BM25 default: TF (saturating, k1=1.2), IDF (rarity), length norm (b=0.75) — Elastic BM25 docs
  ✅ IDF computed per shard; dfs_query_then_fetch gathers global term stats — Elastic / Definitive Guide
  ✅ Query context scores; filter context is yes/no, cached, faster — Elastic query/filter context docs
  ✅ Default size=10; from+size capped at 10,000 via index.max_result_window — Elastic paginate docs
  ✅ search_after (with tie-breaker) + PIT for deep/consistent paging; scroll deprecated for deep paging — Elastic

INFERENCE / ANALOGY (💡): "find first, fetch last"; back-of-book lookup; the résumé trace and
  illustrative scores (0.61/0.58) are made-up teaching numbers.

FLAGGED (⚠️):
  ⚠️ Per-shard IDF can cause minor score variance for the same doc across shards
  ⚠️ Using a different analyzer at query vs index time is a common cause of "no results"

OUTLIERS: 0  |  REMOVED: 0  |  BOGUS CAUGHT: 0  |  UNRESOLVED: 0
TIER 4 SOURCES EXCLUDED: all (none used)
INDUSTRY-FUNDED: Elastic docs used only for authoritative product behavior; no competitive claims.
OVERALL CONFIDENCE: High  |  GAPS DISCLOSED: Yes (aggregations, vector/hybrid search are their own topics)
═══════════════════════════════════════════════════════════
```

---

## 12. Sources & Cross-References
[TYPE: REFERENCE]

### 12.1 Sources & References

**Primary Research (Tier 1 — official vendor documentation)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Elastic | Query and filter context (`_score`, caching) | current | https://www.elastic.co/docs/reference/query-languages/query-dsl/query-filter-context |
| Elastic | Paginate search results (`from`/`size`, `max_result_window`, `search_after`, PIT) | current | https://www.elastic.co/docs/reference/elasticsearch/rest-apis/paginate-search-results |
| Elastic | Similarity / BM25 (k1=1.2, b=0.75) | current | https://www.elastic.co/docs/reference/elasticsearch/index-settings/similarity |
| Elastic | Practical BM25 (TF/IDF/length normalization) | 2024 | https://www.elastic.co/blog/practical-bm25-part-2-the-bm25-algorithm-and-its-variables |
| Elastic | The Definitive Guide — Distributed Search Execution (query-then-fetch, dfs) | 2015 | https://www.elastic.co/guide/en/elasticsearch/guide/current/distributed-search.html |

**Secondary Research (Tier 3 — corroboration only)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Wix Engineering | How Reads, Writes and Search work in the cluster | 2021 | https://medium.com/wix-engineering/elasticsearch-how-reads-writes-and-search-work-in-the-cluster-5e011aaa7de9 |

**Further Reading**

- Elastic docs — "Query DSL" (full list of query types and their options).
- Elastic docs — "kNN search" and "semantic search" for vector/hybrid retrieval.

### 12.2 Document Cross-References

| Relationship | Document | Reason |
|--------------|----------|--------|
| [DEPENDS_ON] | 010 Elasticsearch-Basics | Uses cluster/shard/replica, inverted index, BM25 from there |
| [DEPENDS_ON] | 020 Elasticsearch-How-Storage-Works | Retrieval reads the exact structures storage built |
| [SEE_ALSO] | 011 Elasticsearch-Vocabulary-By-Example | The 3-résumé scenario this traces end-to-end |
| [EXTENDS] → | 040 Elasticsearch-Semantic-RAG-and-MCP | Hybrid/semantic search and RAG build directly on this query path |

> **Bidirectional note:** Reciprocal references added to `010`, `011`, and `020` (their cross-reference
> tables) per Documentation Standards rule 16. A `000` master index can now link all four documents.

---

## 13. Revision History

| Version | Date | Change Type | System Version | Description | Reason |
|---------|------|-------------|----------------|-------------|--------|
| 1.0 | 2026-06-27 | Initial | Elasticsearch 9.4.2 | First version — retrieval internals (query-then-fetch, analysis, inverted-index read, BM25, contexts, pagination) | User requested the read/search deep-dive to complete the storage→retrieval pair |
| 1.1 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Added [EXTENDS] reference to new doc 040 (semantic/RAG/MCP) | Applied/advanced doc authored; reciprocal reference required by Documentation Standards rule 16 |

---

*Template: TMPL-002 Technical Reference v1.0 (adapted for an in-depth explainer) | Parent: 010 Elasticsearch-Basics*
