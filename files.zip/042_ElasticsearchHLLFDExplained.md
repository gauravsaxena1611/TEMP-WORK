---
# ── RULES-001 STANDARD FIELDS ──────────────────────────────
document_id: "042 Elasticsearch-HLLFD-Explained"
title: "The Two High-Level Logical Flow Diagrams, Explained — Storing & Retrieval"
version: "1.0"
created: "2026-06-27"
status: "Draft"
parent_document: "040 Elasticsearch-Semantic-RAG-and-MCP"

# ── SYSTEM VERSION LOCK ──────────────────────────────────────
system_name: "Elasticsearch"
system_version: "9.4.2"
applies_from: "2026-05-28"
supersedes_version: ""

# ── AI-OPTIMIZATION EXTENSION ───────────────────────────────
intent: >
  Explain, in plain English, the two High Level Logical Flow (HLLFD) diagrams
  for the BookWorm system: one for STORING (indexing) and one for RETRIEVAL
  (search & RAG). Teaches how to read the three-lane HLLFD layout and walks
  every numbered workflow step in both diagrams.

consumption_context:
  - human-reading
  - ai-reasoning

triggers:
  - "explain the HLLFD diagrams"
  - "high level logical flow storing retrieval elasticsearch"
  - "how does the storing flow work end to end"
  - "how does the retrieval flow work end to end"

negative_triggers:
  - "on-disk segment file internals"   # → 020 storage doc
  - "query then fetch shard internals"  # → 030 retrieval doc

volatility: "stable"
template_version_used: "TMPL-008 Data & Flow (adapted, beginner-friendly)"
methodology_phase: "N/A — not architecture corpus"

research_validated: true
research_validated_date: "2026-06-27"
research_queries_used:
  - "(reuses verification from docs 020, 030, 040, 041 — no new claims introduced)"

review_trigger: "When ES major version changes, or the storing/retrieval flow changes materially"

confidence_overall: "high"
confidence_note: >
  Restates facts already verified in 020/030/040/041 against official Elastic docs.
  No new external claims introduced.

# ── COMPANION DIAGRAMS ──────────────────────────────────────
figures:
  - "BookWorm-HLLFD-Storing-Technical.drawio — the storing/indexing logical flow"
  - "BookWorm-HLLFD-Retrieval-Technical.drawio — the retrieval (search & RAG) logical flow"
---

> ## 🤖 AI Summary
> **System:** Elasticsearch v9.4.2 (+ embedding models, optional LLM/MCP)
> **Core Purpose of this doc:** Explain the two HLLFD diagrams — one for **storing**, one for **retrieval**.
> **Key Takeaways:**
> - An HLLFD reads in three lanes: **INPUTS** (left) → **PROCESSING** (centre) → **CONSUMES** (right),
>   with **users above** and the **data store below**; arrows are **numbered** to show order.
> - **Storing** (9 steps): trigger → store file → extract text → chunk → embed → index → searchable.
> - **Retrieval** (10 steps): ask → embed query → keyword + vector search → fuse (RRF) → either return
>   results (plain search) or augment + generate (RAG) → answer with citation.
> - The **Elasticsearch index is the bridge**: storing fills it, retrieval reads it.
> **Trust Level:** HIGH — restates facts verified in `020`/`030`/`040`/`041`.
> **See diagrams:** `BookWorm-HLLFD-Storing-Technical.drawio`, `BookWorm-HLLFD-Retrieval-Technical.drawio`.

---

### 📌 Label key

| Tag | Meaning |
|-----|---------|
| ✅ | Verified against official Elastic documentation (in `020`/`030`/`040`/`041`) |
| 💡 | Teaching analogy or illustrative example |
| ⚠️ | True, but with a caveat worth knowing |

---

## TABLE OF CONTENTS

1. [What a High-Level Logical Flow Diagram Is](#1-what-a-high-level-logical-flow-diagram-is)
2. [How to Read the Three Lanes](#2-how-to-read-the-three-lanes)
3. [Why Two Diagrams](#3-why-two-diagrams)
4. [Diagram 1 — Storing (Indexing)](#4-diagram-1--storing-indexing)
5. [Diagram 2 — Retrieval (Search & RAG)](#5-diagram-2--retrieval-search--rag)
6. [How the Two Diagrams Connect](#6-how-the-two-diagrams-connect)
7. [Quick Reading Guide & Takeaways](#7-quick-reading-guide--takeaways)
8. [Verification Record](#8-verification-record)
9. [Sources & Cross-References](#9-sources--cross-references)
10. [Revision History](#10-revision-history)

---

## 1. What a High-Level Logical Flow Diagram Is
[TYPE: CONTEXT]

A **High-Level Logical Flow Diagram (HLLFD)** answers one question simply: *“What are the main building
blocks, and how does work flow through them, in order?”* 💡 “High-level” means we show **logical
components** (the *roles* — extractor, chunker, index) rather than low-level code or servers.
“Logical flow” means we **number the steps** so you can follow the journey 1 → 2 → 3.

It's different from the sequence diagram in `041`: a sequence diagram emphasises **time and back-and-forth
messages between participants**, while an HLLFD emphasises **the layout of components and the one-way flow
of data through them.** 💡 Same system, two lenses.

---

## 2. How to Read the Three Lanes
[TYPE: REFERENCE]

Both diagrams use the same three-lane layout. Learn it once and both read easily: 💡

- **INPUTS (left lane)** — where things *come from*: the source files (or the incoming question) and the
  external **model services** the pipeline calls (the embedding model). 💡
- **PROCESSING (centre lane)** — the **core components** that do the work, shown as boxes. This is the
  “engine room.” ✅
- **CONSUMES (right lane)** — where results *go to*: object storage, the LLM, the downstream search layer,
  or the final answer. 💡
- **Users (top)** — who triggers the flow (an admin/scheduler for storing; an end user for retrieval). 💡
- **The data store (the green cylinder)** — the **Elasticsearch index**, drawn near the centre/bottom,
  because everything ultimately reads from or writes to it. ✅
- **Numbered blue arrows** — the **workflow**. Follow them in order. A letter suffix (`3a`, `3b`) means
  those steps happen **in parallel**. ✅
- **Legend, Workflow Notes, Metadata** — the boxes along the bottom: a key to the shapes/colours, a
  plain-English list of every numbered step, and the diagram's “stamp” (type, audience, date). 💡

> 💡 **One habit:** always read the **numbered Workflow Notes box** alongside the arrows. The numbers on
> the arrows and the numbers in the notes are the same list, said two ways.

---

## 3. Why Two Diagrams
[TYPE: CONTEXT]

Storing and retrieving are **two different jobs that happen at different times**, so they get one diagram
each: 💡

- **Storing (indexing)** happens **once per file**, up front — it *fills* the index.
- **Retrieval (search & RAG)** happens **every time someone asks a question** — it *reads* the index.

Splitting them keeps each diagram simple and honest about *when* the work happens. ✅ The shared
**Elasticsearch index** is the hinge between them (Section 6).

---

## 4. Diagram 1 — Storing (Indexing)
[TYPE: PROCEDURE]

> File: `BookWorm-HLLFD-Storing-Technical.drawio`

### 4.1 The layout

- **INPUTS:** the **Source files** (PDF, DOCX, MP3, MP4) and the **Embedding Model** (ELSER/E5), shown
  dashed because it's an external service the pipeline calls. ✅
- **PROCESSING:** the **Ingestion Pipeline** with four components in order — **Text Extractor → Chunker →
  Embedder → Indexer** — plus the **Elasticsearch index** (the green cylinder) and a note listing what it
  builds per chunk. ✅
- **CONSUMES:** **Object Storage (S3)** for the original files, and the **Search / Retrieval layer**
  (which is Diagram 2) that will later read the index. 💡
- **User (top):** the **ingestion trigger** — an admin uploading files or a scheduler. 💡

### 4.2 The 9 numbered steps (plain English)

1. **Trigger ingestion.** An admin or scheduler kicks off the process. 💡
2. **Store the original file.** The pipeline saves the real PDF/MP4 in Object Storage and gets back a
   `file_url` pointer. ✅ *(The real file lives outside Elasticsearch.)*
3. **Read the source file.** The Extractor takes the file in. 💡
4. **Extract plain text.** Tika reads PDF/DOCX; Whisper transcribes audio/video; out comes plain text. ✅
5. **Chunk it.** The Chunker splits the text into passages. ✅
6. **Embed each chunk.** The Embedder sends every chunk to the Embedding Model and gets back a **vector**. ✅
7. **Hand over chunk + vector.** The Embedder passes each chunk (text + its vector) to the Indexer. 💡
8. **Index the chunks.** The Indexer writes each chunk — **text + vector + metadata** — into the
   Elasticsearch index. ✅
9. **Searchable.** After ~1 second (refresh), the chunks are findable; the Retrieval layer can now use
   them. ✅

### 4.3 The shortcut (the Alt note)

The note at the bottom reminds you: with **`semantic_text`**, you send the **raw text once** and
Elasticsearch performs steps **4–8 internally** (chunk + embed + store as nested chunks). ✅ That's the
“out-of-the-box” path from `040 §8`; the diagram's main flow is the “build-your-own” path. 💡

---

## 5. Diagram 2 — Retrieval (Search & RAG)
[TYPE: PROCEDURE]

> File: `BookWorm-HLLFD-Retrieval-Technical.drawio`

### 5.1 The layout

- **INPUTS:** the **incoming question** and the **Query Embedding Model** (to turn the question into a
  query vector — same model family used at indexing time). ✅
- **PROCESSING:** the **Search + RAG** components — **Query Analyzer → (Keyword Retriever ‖ Vector
  Retriever) → RRF Fusion + query-then-fetch → RAG Orchestrator** — plus the **Elasticsearch index** and
  an **MCP** alt-note. ✅
- **CONSUMES:** the **LLM** (writes the answer), **Object Storage** (fetch the original file for the
  citation), and the **Answer → user**. 💡
- **User (top):** the **end user / chatbot** asking the question. 💡

### 5.2 The 10 numbered steps (plain English)

1. **Ask.** The user types a natural-language question. 💡
2. **Embed the query.** The Query Analyzer turns the question into a **query vector** (and analyses the
   text for keyword matching). ✅
3. **Fan out.** It sends the analysed text to the **Keyword Retriever** (3a) and the query vector to the
   **Vector Retriever** (3b). These run **in parallel**. ✅
4. **Search the index.** Keyword does a **BM25** search (4a); Vector does a **kNN** search (4b) — both
   against the same Elasticsearch index. ✅
5. **Fuse.** **RRF** merges the two result lists into one ranking, and **query-then-fetch** pulls the
   `_source` for the top results. ✅
6. **Plain-search path.** If the user just wanted results, the ranked chunks (with source + metadata) go
   straight back to the user. ✅ *(Reminder from `040 §10`: search has uses beyond RAG.)*
7. **RAG path.** If the user wanted a written answer, the top chunks go to the **RAG Orchestrator**. ✅
8. **Augment + generate.** It puts those chunks into the LLM's prompt and asks the LLM to write a grounded
   answer. ✅
9. **Fetch the file.** It pulls the original file from Object Storage for the citation. 💡
10. **Answer.** The grounded answer + citation is returned to the user. ✅

### 5.3 The agentic alternative (the MCP note)

The note inside Processing says: with the **MCP server**, an **AI agent** can drive steps 1–5 itself by
calling Elasticsearch's tools (`search`, `get_mappings`…), searching and refining repeatedly, then
generate. ✅ That's the “agentic” style from `040 §9`, versus the fixed one-shot flow drawn here. 💡

---

## 6. How the Two Diagrams Connect
[TYPE: REFERENCE]

The **Elasticsearch index is the bridge** between the two diagrams: 💡

```
   STORING (Diagram 1)                         RETRIEVAL (Diagram 2)
   files → … → Indexer ──writes──►  [ Elasticsearch index ]  ◄──reads── Retrievers → … → answer
                                     (inverted index + vectors
                                      + _source + metadata)
```

- Diagram 1's last step (8) **writes** chunks into the index. ✅
- Diagram 2's step 4 **reads** from that same index. ✅
- Diagram 1's CONSUMES lane even names the “Search / Retrieval layer” — which *is* Diagram 2. 💡

So the two flows are not separate systems; they're the **write side** and the **read side** of one index. 💡

---

## 7. Quick Reading Guide & Takeaways
[TYPE: REFERENCE]

- **Read left → right, top → bottom, and follow the numbers.** The numbered Workflow Notes box is your
  guide. 💡
- **Storing = fill the index** (once per file); **retrieval = read the index** (per question). ✅
- **The same embedding model** is used at storing time (on chunks) and retrieval time (on the query) — so
  the vectors line up. ✅
- **Hybrid (keyword + vector, fused by RRF)** is the production default for the retrieval search step. ✅
- **Two “out-of-the-box” shortcuts** appear as alt-notes: `semantic_text` (storing) and the **MCP server**
  (retrieval). ✅
- **Original files stay in object storage**; the index holds text + vectors + a pointer. ✅

---

## 8. Verification Record
[TYPE: REFERENCE]

```
VERIFICATION RECORD
═══════════════════════════════════════════════════════════
Task:    Explain the two HLLFD diagrams (storing + retrieval) in simple English
Mode:    MEDIUM-HIGH (technical documentation)
Session: 2026-06-27

VERIFIED CLAIMS (✅): all restated from prior verified docs; no new external claims
  ✅ Ingest order: extract → chunk → embed → index; searchable after ~1s refresh — docs 020/040/041
  ✅ Original files stored outside ES; index holds text + vectors + metadata + pointer — docs 020/040
  ✅ Tika extracts PDF/DOCX; Whisper transcribes audio/video — docs 011/040
  ✅ semantic_text does chunk+embed internally (storing shortcut) — doc 040
  ✅ Retrieval: query embedded; BM25 + kNN in parallel; RRF fusion; query-then-fetch — docs 030/040
  ✅ RAG: augment prompt with chunks → LLM generates grounded answer + citation — doc 040
  ✅ MCP server lets an agent drive retrieval via ES tools (agentic) — doc 040
  ✅ Search has uses beyond RAG (plain-search branch) — doc 040

INFERENCE / ILLUSTRATION (💡): BookWorm scenario, lane-reading habits, the "bridge" framing.

FLAGGED (⚠️):
  ⚠️ Diagrams show the happy path and serialise some steps for clarity (real flows bulk/parallelise)
  ⚠️ "vector index" simplified; precise: HNSW for dense, sparse_vector for ELSER (see doc 041 §7)

OUTLIERS: 0 | REMOVED: 0 | BOGUS CAUGHT: 0 | UNRESOLVED: 0
OVERALL CONFIDENCE: High | GAPS DISCLOSED: Yes (low-level internals are in 020/030)
═══════════════════════════════════════════════════════════
```

---

## 9. Sources & Cross-References
[TYPE: REFERENCE]

### 9.1 Sources & References

This document introduces **no new external claims**; every fact is carried from, and cited in, the
documents below.

**Primary basis (verified in prior docs)**

| Source | Where verified | Used for |
|--------|----------------|----------|
| Elastic official docs | `020`, `030`, `040`, `041` | Ingest/refresh, query-then-fetch, RRF, semantic_text, MCP, vector storage |

**Further Reading**

- `040 §4` (ingestion), `§6–7` (search & RAG), `§8–9` (OOTB vs DIY, MCP).
- `030` (query-then-fetch + BM25), `020` (storage structures), `041` (ingestion sequence).

### 9.2 Document Cross-References

| Relationship | Document | Reason |
|--------------|----------|--------|
| [DEPENDS_ON] | 040 Elasticsearch-Semantic-RAG-and-MCP | Visualises its end-to-end storing and retrieval flows |
| [DEPENDS_ON] | 030 Elasticsearch-How-Retrieval-Works | Retrieval HLLFD builds on query-then-fetch + BM25 |
| [DEPENDS_ON] | 020 Elasticsearch-How-Storage-Works | Storing HLLFD builds on the index structures |
| [SEE_ALSO] | 041 Elasticsearch-Ingestion-Sequence-Explained | Sequence-diagram view of the same storing flow |

> **Bidirectional note:** Reciprocal reference added to `040` (cross-reference table + figures) per
> Documentation Standards rule 16.

### 9.3 Companion Diagrams

| Diagram | File | Shows |
|---------|------|-------|
| Storing HLLFD | `BookWorm-HLLFD-Storing-Technical.drawio` | Inputs → pipeline → index; 9 numbered steps |
| Retrieval HLLFD | `BookWorm-HLLFD-Retrieval-Technical.drawio` | Question → search + RAG → answer; 10 numbered steps |

---

## 10. Revision History

| Version | Date | Change Type | System Version | Description | Reason |
|---------|------|-------------|----------------|-------------|--------|
| 1.0 | 2026-06-27 | Initial | Elasticsearch 9.4.2 | First version — explains the storing and retrieval HLLFD diagrams in simple English | User requested two detailed HLLF diagrams plus an explanation document |

---

*Template: TMPL-008 Data & Flow (adapted, beginner-friendly) | Parent: 040 Elasticsearch-Semantic-RAG-and-MCP*
