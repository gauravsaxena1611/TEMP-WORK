---
# ── RULES-001 STANDARD FIELDS ──────────────────────────────
document_id: "020 Elasticsearch-How-Storage-Works"
title: "How Storage Works — Where & How Elasticsearch Stores Your Data"
version: "1.2"
created: "2026-06-27"
status: "Draft"
parent_document: "010 Elasticsearch-Basics"

# ── SYSTEM VERSION LOCK ──────────────────────────────────────
system_name: "Elasticsearch"
system_version: "9.4.2"
applies_from: "2026-05-28"
supersedes_version: ""

# ── AI-OPTIMIZATION EXTENSION ───────────────────────────────
intent: >
  Give a deep but plain-English account of what Elasticsearch actually
  writes to disk: where the JSON and indexes physically live, how the
  inverted index and _source are built and structured, what "separate
  fields" means, the difference between tokens and chunks, and the
  real-world write path from a document to searchable files.

consumption_context:
  - human-reading
  - ai-reasoning

triggers:
  - "where does elasticsearch store data on disk"
  - "how is the inverted index built and structured"
  - "what is _source and how is it stored"
  - "tokens vs chunks elasticsearch"
  - "elasticsearch lucene segment files explained"

negative_triggers:
  - "elasticsearch query DSL syntax"          # → retrieval doc / API ref
  - "how to size a production cluster"          # → ops/tuning doc

volatility: "stable"
template_version_used: "TMPL-002 v1.0 (adapted for an in-depth explainer)"
methodology_phase: "N/A — not architecture corpus"

research_validated: true
research_validated_date: "2026-06-27"
research_queries_used:
  - "Elasticsearch path.data directory structure where shard segment files stored on disk"
  - "Apache Lucene index file formats segment .tim .doc .pos .fdt stored fields .dvd doc values codec"
  - "Elasticsearch semantic_text chunking strategy chunks vector embeddings default"
  - "Elasticsearch _source stores original document analyzed text only for indexing"

review_trigger: "When system_version major number changes, or Lucene codec/file formats change materially"

confidence_overall: "high"
confidence_note: >
  Physical layout (path.data, per-shard translog, Lucene segment files) and
  the inverted-index / _source / doc-values split verified against official
  Elastic and Apache Lucene documentation. Exact on-disk filenames include a
  codec version (e.g. Lucene99) and may bundle into compound files.
---

> ## 🤖 AI Summary
> **System:** Elasticsearch v9.4.2 (on Apache Lucene)
> **Core Purpose of this doc:** Explain what Elasticsearch physically stores and where.
> **Key Takeaways:**
> - One document is written into **three different structures**: the **inverted index**
>   (to *find*), **`_source`** (to *return* the original JSON), and **doc values**
>   (to *sort/aggregate*) — plus **points/BKD** for numbers/dates and **vectors** for semantic search.
> - It all lives on disk under **`path.data`** → `indices/<index>/<shard>/` → a **Lucene index**
>   made of immutable **segment files** + a **translog** for crash safety.
> - **Tokens** = small units for keyword search; **chunks** = larger passages for semantic/vector search. Different jobs.
> - The original **PDF file** is *not* kept by Elasticsearch by default — you store it elsewhere and use ES to find it.
> **Trust Level:** HIGH — verified against official Elastic + Apache Lucene docs.
> **Builds On:** `010 Elasticsearch-Basics`, `011 Vocabulary-By-Example`.

---

### 📌 Label key

| Tag | Meaning |
|-----|---------|
| ✅ | Verified against official Elastic / Apache Lucene documentation |
| 💡 | Teaching analogy or inference built on verified facts |
| ⚠️ | True, but with a caveat worth knowing |

---

## TABLE OF CONTENTS

1. [The Core Idea: One Document, Several Structures](#1-the-core-idea-one-document-several-structures)
2. [Where It All Physically Lives (the disk answer)](#2-where-it-all-physically-lives-the-disk-answer)
3. [How the Inverted Index Is Built & Structured](#3-how-the-inverted-index-is-built--structured)
4. [How the `_source` Field Is Built & Structured](#4-how-the-_source-field-is-built--structured)
5. [The "Separate Fields" Concept — 5 Examples](#5-the-separate-fields-concept--5-examples)
6. [Tokens vs Chunks](#6-tokens-vs-chunks)
7. [Where the Original PDF Goes](#7-where-the-original-pdf-goes)
8. [The Real-World Write Path (putting it together)](#8-the-real-world-write-path-putting-it-together)
9. [One-Page Summary](#9-one-page-summary)
10. [Verification Record](#10-verification-record)
11. [Sources & Cross-References](#11-sources--cross-references)
12. [Revision History](#12-revision-history)

---

## 1. The Core Idea: One Document, Several Structures
[TYPE: CONTEXT]

The single biggest "aha" of Elasticsearch storage: **when you index one JSON document, it isn't
saved once — it's written into several different on-disk structures, each optimized for a
different job.** 💡 The same document feeds:

| Structure | Its job | "Lossy"? |
|-----------|---------|----------|
| **Inverted index** | *Find* documents by word (full-text/keyword search) | Yes — analyzed, lowercased; that's fine, it's only for matching ✅ |
| **`_source`** | *Return* the exact original JSON you sent | No — stored verbatim ✅ |
| **Doc values** | *Sort, aggregate, group* on a field (columnar) | No — exact values, column-oriented ✅ |
| **Points (BKD tree)** | *Range/numeric/geo* searches on numbers & dates | No ✅ |
| **Vectors (HNSW)** | *Semantic / similarity* search (embeddings) | No — but the text is chunked first ✅ |

Everything below is really just "how each of these is built and where it lands on disk."
Lucene — the engine Elasticsearch wraps — is what actually writes these. ✅

---

## 2. Where It All Physically Lives (the disk answer)
[TYPE: REFERENCE]

You asked the key question: *Elasticsearch is an engine built on Lucene — but where do the JSONs
and indexes get stored?* Here is the concrete answer.

Elasticsearch writes everything you index into a single directory on each node called
**`path.data`.** ✅ Elasticsearch writes the data you index to indices and data streams to a data directory; in production you should set `path.data` to a location outside the install folder. ⚠️ You should never edit anything inside it by hand — if something other than Elasticsearch modifies the data directory, Elasticsearch may fail or report corruption.

Inside `path.data`, the layout drills down node → index → shard → Lucene files: 💡 *(representative
tree; real filenames include a codec version like `Lucene99` and small files are bundled — see below)* ✅

```
path.data/
└── indices/
    └── <index-uuid>/                  ← one INDEX (e.g. "resumes")
        ├── 0/                         ← SHARD 0  (this shard *is* one Lucene index)
        │   ├── index/                 ← the Lucene index = a folder of SEGMENT files
        │   │   ├── segments_N         ← lists the active segments (the "commit point")
        │   │   ├── write.lock         ← only one writer at a time
        │   │   ├── _0.si              ← segment info (name, doc count, codec)
        │   │   ├── _0_Lucene99_0.tim  ← TERM DICTIONARY  ┐
        │   │   ├── _0_Lucene99_0.tip  ← term index       │ the INVERTED INDEX
        │   │   ├── _0_Lucene99_0.doc  ← postings: doc ids + term freqs │
        │   │   ├── _0_Lucene99_0.pos  ← positions (for phrases)        ┘
        │   │   ├── _0.fdt / .fdx / .fdm ← STORED FIELDS  (this is where _source lives)
        │   │   ├── _0_Lucene90_0.dvd/.dvm ← DOC VALUES (sort/aggregate, columnar)
        │   │   ├── _0.kdd/.kdi/.kdm   ← POINTS / BKD tree (numbers, dates, geo)
        │   │   ├── _0.fnm             ← field infos (what fields exist, how indexed)
        │   │   └── _0.nvd / .nvm      ← norms (length factors used by BM25)
        │   ├── translog/              ← the TRANSACTION LOG (crash safety)
        │   │   ├── translog-N.tlog
        │   │   └── translog.ckp
        │   └── _state/                ← shard-level metadata
        └── 1/                         ← SHARD 1 (another Lucene index) ...
```

Three things to read out of this tree: 💡

1. **An Elasticsearch index is a folder; a shard is a Lucene index; a Lucene index is a pile of
   *segment* files.** ✅ *(Each shard corresponds to a Lucene index — Elastic.)* Files whose names
   start with `_0` belong to segment 0, `_1` to segment 1, and so on. ✅
2. **The different structures from Section 1 are literally different file extensions** in that
   folder — `.tim/.tip/.doc/.pos` (inverted index), `.fdt/.fdx` (stored fields = `_source`),
   `.dvd/.dvm` (doc values), `.kdd/.kdi` (points). ✅ *(Apache Lucene file formats; confirmed in a
   real Lucene99-codec segment by Lucene's own teaching material.)*
3. **Small segments are often bundled** into one compound file `_0.cfs` (+ `_0.cfe` index) so the
   OS doesn't juggle dozens of tiny files. ✅ *(Lucene compound-file format.)*

> 💡 **Mental model:** `path.data` is the warehouse; each **index** is an aisle; each **shard** is
> a shelf that is a complete mini search-engine; each **segment** is one sealed box on that shelf
> (never reopened once written — recall immutability from `010`).

---

## 3. How the Inverted Index Is Built & Structured
[TYPE: REFERENCE]

### 3.1 Building it: the analysis pipeline

Text doesn't go into the inverted index as-is. It first runs through an **analyzer**, which has
three stages: 💡 *(stage roles per official Elastic analysis docs)*

```
  raw text → [1] character filters → [2] tokenizer → [3] token filters → TOKENS
  "Fire & ICE!"  (strip "&")          (split words)   (lowercase, etc.)   [fire, ice]
```

- **Character filters** tweak the raw string (e.g. strip HTML, replace characters). ✅
- **Tokenizer** splits the stream into **tokens** — usually one per word — and records each
  token's **position** and **character offsets**. ✅
- **Token filters** transform tokens: lowercase, remove stop-words, apply stemming
  (`running → run`), add synonyms, etc. ✅

The surviving tokens are what get written into the inverted index. ✅

### 3.2 Its structure: term dictionary + postings

The inverted index has two main parts on disk: 💡

1. **Term dictionary** — every distinct term, sorted, so a term can be found fast. ✅ Stored in
   `.tim` (the dictionary) with a small in-memory `.tip` **term index** that points into it. ✅
2. **Postings list** — for each term, the list of documents that contain it. ✅ Stored in `.doc`
   (document ids + term frequencies). Optional companions: `.pos` (**positions** — which enable
   phrase queries), and offsets/payloads. ✅ *(Lucene PostingsFormat covers "fields, terms,
   documents, positions, payloads and offsets.")*

```
  TERM        →  POSTINGS (doc : freq : positions)
  ──────────────────────────────────────────────
  python      →  doc1:1:[2]   doc3:2:[1, 9]
  developer   →  doc1:1:[3]   doc2:1:[3]
  toronto     →  doc1:1:[7]   doc3:1:[6]
```

So the index "remembers" word order after all — not as readable text, but as **positions**
attached to each term, which is exactly what phrase and proximity search read. ✅ Term
**frequencies** and length **norms** (`.nvd/.nvm`) are also stored here — that's the raw material
BM25 uses to score relevance. ✅

---

## 4. How the `_source` Field Is Built & Structured
[TYPE: REFERENCE]

`_source` is the opposite kind of structure. While the inverted index is organized **by term**,
`_source` is organized **by document** (row-oriented). ✅

- **What it is:** the **original JSON body** you sent at index time, kept byte-for-byte.
  The `_source` field contains the original JSON document body passed at index time; it is not indexed (not searchable), but it is stored so it can be returned on get/search. ✅
- **Where it lands:** in Lucene **stored fields** — the `.fdt` (field data), `.fdx` (index into
  it), `.fdm` (metadata) files. ✅ *(Lucene stored-fields format.)*
- **How it's packed:** stored fields are **compressed** in blocks (LZ4 for speed by default; a
  higher-ratio `best_compression` mode exists). ✅ *(Elastic "What is a Lucene Codec" — stored
  fields have best-speed vs best-compression modes.)*

This is why analysis never harms what you get back: the lossy tokens live in the inverted index,
while `_source` returns your JSON with original casing, punctuation, and field order intact. ✅
It's also why `_source` powers features like **reindexing**, **update**, and **highlighting** —
they all need the original text. ✅ *(Official Elastic `_source` docs.)*

> 💡 **One document, two filings:** the inverted index is the *back-of-book index* (by word);
> `_source` is the *photocopy of the page* (by document). Same content, filed two ways for two jobs.

---

## 5. The "Separate Fields" Concept — 5 Examples
[TYPE: REFERENCE]

When a PDF becomes a document, you don't dump everything into one blob. You split it into
**fields**, and *each field's type decides which storage structures get built for it.* ✅ That is
the whole point of "separate fields": the same document can be full-text-searchable on one field,
exactly-filterable on another, and sortable on a third. 💡

Imagine indexing a PDF research paper. Five fields, five different storage behaviors: ✅

| # | Field | Type | What gets built for it | Lets you… |
|---|-------|------|------------------------|-----------|
| 1 | `title` | `text` | Inverted index (`.tim/.doc/.pos`) + norms | Full-text search the title, ranked by relevance |
| 2 | `authors` | `keyword` | Inverted index (exact term) + **doc values** | Filter `authors = "Smith"`, and aggregate "papers per author" |
| 3 | `published` | `date` | **Points/BKD** (`.kdd`) + doc values | Range queries (`after 2024`) and sort by date |
| 4 | `content` | `text` | Inverted index over the whole PDF body | Search the full text, do phrase queries, highlight |
| 5 | `page_count` | `integer` | Points/BKD + doc values | `page_count > 10`, sort, average, histogram |

Two clarifications people always need: 💡

- **`text` vs `keyword`:** a `text` field is **analyzed** (broken into tokens) for relevance
  search; a `keyword` field is stored **whole and exact**, for filters, sorting, and aggregations.
  The same value is often mapped both ways (e.g. `title` as text, `title.keyword` as keyword). ✅
- **`_source` still has all five fields together**, untouched — regardless of each field's type.
  The per-field structures above are *extra* indexes built *alongside* `_source` to make each
  field searchable/sortable in its own way. ✅

> **Bonus 6th — semantic search:** a field typed `semantic_text` makes Elasticsearch automatically
> **chunk** the long text, generate an **embedding vector** per chunk, and store those vectors for
> similarity search. ✅ *(Official Elastic `semantic_text` docs — it "handles chunking" and
> "generates embeddings during indexing" automatically.)* That bridges us to the next section.

---

## 6. Tokens vs Chunks
[TYPE: REFERENCE]

These two words sound similar and both mean "split the text up," but they belong to **two
different kinds of search** and operate at **different sizes.** 💡

| | **Token** (a.k.a. term) | **Chunk** |
|--|--------------------------|-----------|
| Size | Tiny — usually one word | Larger — a sentence, passage, or paragraph |
| Made by | The **analyzer** (tokenizer + filters) | A **chunking strategy** (by word/sentence count) |
| Powers | **Lexical** search (BM25, the inverted index) | **Semantic / vector** search (embeddings, kNN) |
| Example | "Fire and ICE" → `fire`, `ice` | A 50-page PDF → 40 passages of ~120 words each |
| Stored as | Terms in the inverted index | Each chunk → one embedding vector |

- **Tokens** exist because keyword search needs small, normalized units to match on. ✅
- **Chunks** exist because embedding models have a limited context window, and because retrieving a
  *relevant passage* beats retrieving a whole 50-page document. Chunking is the process of breaking large documents into smaller, semantically meaningful pieces that can be individually embedded and searched — necessary when documents are longer than the embedding model's context window, or when you need to retrieve specific passages. ✅

In modern Elasticsearch, the `semantic_text` field does chunking + embedding **for you** at index
time, and the resulting chunks are stored in a nested object structure so each chunk's text and vector live with the document. ✅ The default behavior is configurable — e.g. a `word` strategy with `max_chunk_size` and `overlap`. ✅ *(Official Elastic `semantic_text` docs.)*

> 💡 **Same document, two granularities:** tokenize it into *words* for keyword search, **and**
> chunk it into *passages* for semantic search. Many real systems do both at once (hybrid search).

---

## 7. Where the Original PDF Goes
[TYPE: REFERENCE]

Critical point that surprises people: **by default, Elasticsearch does not keep your original
`.pdf` file.** ✅ It stores the *extracted text* (in the inverted index and in `_source`), but not
the binary file with its fonts and layout — Elasticsearch is a search engine, not a file store. 💡

So where does the PDF live? You have three common patterns: 💡

1. **Keep the file outside ES (most common).** Store `alice.pdf` on disk, in object storage
   (S3/GCS/Azure Blob), or a CMS. In Elasticsearch, store only the text **plus a pointer** like
   `"file_url": "s3://bucket/alice.pdf"`. Search finds the document → your app serves the original
   file from storage. 💡 *(Standard "find in ES, fetch the file elsewhere" pattern.)*
2. **Store the raw bytes inside ES as a field** (base64 / `binary` type) if you really want
   everything in one place — but this bloats the index and the bytes aren't searchable; the
   attachment processor can even remove the base64 after extracting text (`remove_binary`). ✅
   *(Official Elastic attachment-processor docs.)*
3. **Store a rendered/derived copy** (e.g. extracted HTML or per-page images) if you need to show
   structure — as additional fields, separate from the searchable text. 💡

The takeaway: **search lives in Elasticsearch; the pixel-perfect original lives wherever you
choose to keep files.** Use ES to answer "*which* PDF," then hand the user the real file. 💡

---

## 8. The Real-World Write Path (putting it together)
[TYPE: REFERENCE]

Here is what actually happens, end to end, when you index a document — and how it becomes
searchable and crash-safe. ✅ *(Sequence per official Elastic "Near real-time search" + the Elastic
storage blog on the translog.)*

```
 1. PUT /resumes/_doc/1  {JSON}
        │
        ▼
 2. Routing picks the shard  →  hash(_id) % primary_shards
        │
        ▼
 3. Document is (a) added to an in-memory buffer
                (b) APPENDED to the translog on disk   ← crash safety, no full commit needed
        │
        ▼
 4. REFRESH (default ≈ every 1s): buffer → a NEW segment in the filesystem cache
        │                          → document is now SEARCHABLE (near-real-time)
        ▼
 5. FLUSH (periodically): segments fsync'd to disk + a Lucene COMMIT is written
        │                  → translog can be trimmed (its job is done once committed)
        ▼
 6. MERGE (background): many small immutable segments → fewer big ones
                         → deleted docs (.liv) are physically dropped here
```

Why each step exists: 💡

- **The translog is the safety net.** A full Lucene commit per document would be far too slow,
  because committing a Lucene index creates a new fsync'd segment, which is a significant amount of disk I/O. So to accept a document and make it searchable without a full commit, Elasticsearch adds it to the Lucene IndexWriter and appends it to the transaction log. ✅ If the node crashes before a flush, ES replays the translog on restart. ✅
- **Refresh** is what creates the ~1-second searchability delay from `010` — it opens a new
  segment so the new doc can be found, without the expense of a full commit. ✅
- **Flush** makes it durable (fsync + commit), after which the translog can be cleared. ✅
- **Merge** keeps search fast by reducing the number of segments, and is when soft-deleted
  documents are actually removed (remember: segments are immutable, so deletes are deferred). ✅

---

## 9. One-Page Summary
[TYPE: REFERENCE]

```
  YOUR JSON DOCUMENT
        │
        ├──► analyzed into TOKENS ─────────────► INVERTED INDEX   (.tim/.tip/.doc/.pos)  → find by word
        │                                                                      + norms (.nvd)   → BM25 scoring
        ├──► kept verbatim ──────────────────► _SOURCE (stored fields .fdt/.fdx) → return original JSON
        │
        ├──► per-field columnar values ──────► DOC VALUES (.dvd/.dvm)           → sort / aggregate
        │
        ├──► numbers & dates ────────────────► POINTS / BKD (.kdd/.kdi)         → range search
        │
        └──► (semantic_text) chunked + embedded ► VECTORS (HNSW)                → similarity search

  ALL of the above live in immutable SEGMENTS, inside a SHARD (= one Lucene index),
  inside an INDEX folder, under  path.data  on each NODE.
  A per-shard TRANSLOG makes writes crash-safe before they're committed.
  The original PDF file is stored OUTSIDE Elasticsearch (or as opaque bytes), not as searchable content.
```

---

## 10. Verification Record
[TYPE: REFERENCE]

```
VERIFICATION RECORD
═══════════════════════════════════════════════════════════
Task:    In-depth storage explainer (disk layout, inverted index, _source, fields, tokens/chunks)
Mode:    MEDIUM-HIGH (technical documentation, deep internals)
Session: 2026-06-27

VERIFIED CLAIMS (✅):
  ✅ Data is written under path.data; don't modify it by hand — Elastic official path settings
  ✅ Per-shard translog directory; translog enables indexing without a full Lucene commit — Elastic storage blog
  ✅ A shard = a Lucene index = a folder of immutable segment files — Elastic / Lucene
  ✅ Inverted index files .tim/.tip (terms), .doc (postings), .pos (positions) — Apache Lucene file formats
  ✅ Positions stored in postings enable phrase queries — Lucene PostingsFormat
  ✅ _source = original JSON, stored (not indexed), in stored fields .fdt/.fdx — Elastic _source docs / Lucene
  ✅ Stored fields are compressed (best-speed vs best-compression modes) — Elastic codec blog
  ✅ Doc values = columnar per-document values for sort/aggregate (.dvd/.dvm) — Lucene DocValuesFormat
  ✅ Points/BKD for numeric/date/geo range search — Lucene file formats (v6.0 Points)
  ✅ Small segments bundled into compound files .cfs/.cfe — Lucene compound-file format
  ✅ Refresh ≈1s creates a new segment → near-real-time searchable — Elastic near-real-time docs
  ✅ text=analyzed for relevance, keyword=exact for filter/sort/agg — Elastic mapping docs
  ✅ semantic_text auto-chunks + embeds; chunks stored in nested structure — Elastic semantic_text docs
  ✅ Chunking = splitting long text into passages for embeddings/RAG — Elastic Search Labs
  ✅ Attachment processor can remove_binary after extracting text — Elastic attachment-processor docs

INFERENCE / ANALOGY (💡): warehouse/shelf/box model; back-of-book vs photocopy; the
  representative directory tree (real names carry codec versions and may be compound files).

FLAGGED (⚠️):
  ⚠️ Exact on-disk filenames depend on the Lucene codec version (e.g. Lucene99) and compound-file bundling
  ⚠️ Never hand-edit path.data — risk of corruption (per Elastic)

OUTLIERS: 0  |  REMOVED: 0  |  BOGUS CAUGHT: 0  |  UNRESOLVED: 0
TIER 4 SOURCES EXCLUDED: all (none used)
INDUSTRY-FUNDED: Elastic/Lucene docs used only for authoritative product/library behavior —
  the correct primary source for how their own software stores data; no competitive claims.
OVERALL CONFIDENCE: High  |  GAPS DISCLOSED: Yes (retrieval/search path is doc 030)
═══════════════════════════════════════════════════════════
```

---

## 11. Sources & Cross-References
[TYPE: REFERENCE]

### 11.1 Sources & References

**Primary Research (Tier 1 — official vendor / library documentation)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Elastic | Path settings (`path.data`) | current | https://www.elastic.co/docs/reference/elasticsearch/configuration-reference/path |
| Elastic | A Dive into the Elasticsearch Storage (translog, shard files) | 2024 | https://www.elastic.co/blog/found-dive-into-elasticsearch-storage |
| Elastic | What is an Apache Lucene Codec? (postings/docvalues/stored-fields formats) | 2025 | https://www.elastic.co/blog/what-is-an-apache-lucene-codec |
| Elastic | `_source` field (original JSON, stored not indexed) | current | https://www.elastic.co/docs/reference/elasticsearch/mapping-reference/mapping-source-field |
| Elastic | Semantic text field type (auto chunking + embeddings) | current | https://www.elastic.co/docs/reference/elasticsearch/mapping-reference/semantic-text |
| Elastic Search Labs | Chunking strategies in Elasticsearch | 2025 | https://www.elastic.co/search-labs/blog/chunking-strategies-elasticsearch |
| Elastic | Near real-time search (refresh, segments, filesystem cache) | current | https://www.elastic.co/docs/manage-data/data-store/near-real-time-search |
| Apache Lucene | Index File Formats (segment file extensions) | — | https://lucene.apache.org/core/9_0_0/core/org/apache/lucene/codecs/lucene90/package-summary.html |

**Secondary Research (Tier 3 — corroboration only)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Lucene University | Bottom-up explanation of how Lucene reads index data (real Lucene99 segment files) | — | https://msfroh.github.io/lucene-university/docs/BottomUpIndexReader.html |

**Further Reading**

- Elastic docs — "Text analysis" (analyzers, tokenizers, token filters) for Section 3 depth.
- Apache Lucene `package-summary` for the current codec — the authoritative file-format list.

### 11.2 Document Cross-References

| Relationship | Document | Reason |
|--------------|----------|--------|
| [DEPENDS_ON] | 010 Elasticsearch-Basics | Uses inverted index, _source, shards, near-real-time from there |
| [DEPENDS_ON] | 011 Elasticsearch-Vocabulary-By-Example | Extends the PDF storing walkthrough into internals |
| [EXTENDS] → | 030 Elasticsearch-How-Retrieval-Works | The matching read path (query→fetch, scoring) that consumes these structures |
| [SEE_ALSO] → | 040 Elasticsearch-Semantic-RAG-and-MCP | Uses chunks/vectors/_source and the "files live elsewhere" pattern from this doc |

> **Bidirectional note:** Reciprocal references added to `010` and `011` (their cross-reference
> tables) per Documentation Standards rule 16. When `030` is created, add its reciprocal reference here.

---

## 12. Revision History

| Version | Date | Change Type | System Version | Description | Reason |
|---------|------|-------------|----------------|-------------|--------|
| 1.0 | 2026-06-27 | Initial | Elasticsearch 9.4.2 | First version — in-depth storage internals (disk layout, inverted index, _source, fields, tokens/chunks, write path) | User requested a deep-dive on how data is physically stored and structured |
| 1.1 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Marked linked doc 030 (retrieval deep-dive) as created | Retrieval deep-dive authored; reciprocal reference required by Documentation Standards rule 16 |
| 1.2 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Added [SEE_ALSO] reference to new doc 040 (semantic/RAG/MCP) | Applied/advanced doc authored; reciprocal reference required by rule 16 |

---

*Template: TMPL-002 Technical Reference v1.0 (adapted for an in-depth explainer) | Parent: 010 Elasticsearch-Basics*
