---
# ── RULES-001 STANDARD FIELDS ──────────────────────────────
document_id: "010 Elasticsearch-Basics"
title: "Elasticsearch Basics — A Plain-English Introduction"
version: "1.4"
created: "2026-06-27"
status: "Draft"
parent_document: "000 Elasticsearch — How It Works (Master Index) [PLANNED — not yet created]"

# ── SYSTEM VERSION LOCK ──────────────────────────────────────
system_name: "Elasticsearch"
system_version: "9.4.2"          # Latest GA at time of writing
applies_from: "2026-05-28"        # Release date of 9.4.2
supersedes_version: ""

# ── AI-OPTIMIZATION EXTENSION ───────────────────────────────
intent: >
  Enable a beginner to build an accurate mental model of what
  Elasticsearch is, the vocabulary it uses, and the high-level
  loop of how data is stored and then found again — as the
  foundation for later deep-dives on storage and retrieval.

consumption_context:
  - human-reading
  - ai-reasoning

triggers:
  - "how does elasticsearch work"
  - "what is elasticsearch"
  - "elasticsearch basics for beginners"
  - "explain inverted index simply"

negative_triggers:
  - "how do I tune shard count for production"   # → future detailed-design doc
  - "elasticsearch query DSL reference"          # → API reference doc

volatility: "stable"
template_version_used: "TMPL-002 v1.0 (adapted for beginner primer)"
methodology_phase: "N/A — not architecture corpus"

research_validated: true
research_validated_date: "2026-06-27"
research_queries_used:
  - "Elasticsearch built on Apache Lucene inverted index official documentation"
  - "Elasticsearch latest version 2026 release"
  - "Elasticsearch BM25 default similarity refresh interval near real-time"

review_trigger: "When system_version major number changes (e.g., 9.x → 10.x)"

confidence_overall: "high"
confidence_note: >
  Core concepts verified against Tier 1 sources (official Elastic docs,
  Apache Lucene docs). These fundamentals are stable across versions.
---

> ## 🤖 AI Summary
> **System:** Elasticsearch v9.4.2
> **Core Purpose:** A distributed search-and-analytics engine that stores data as JSON
> "documents" and finds them in milliseconds using an *inverted index*.
> **Key Specifications:**
> - Built on the Apache Lucene search library; spoken to over a REST/JSON API.
> - Data lives in *indices*, which are split into *shards* (each shard is a Lucene index).
> - Default relevance ranking is **BM25**; search is **near-real-time** (~1 second).
> **Trust Level:** HIGH — verified against official Elastic and Apache Lucene documentation.
> **Do NOT Use This For:** Production tuning, query syntax reference, or cluster sizing —
> those belong in later, more detailed documents.

---

### 📌 How to read the labels in this document

Per the project's Verification Standards, factual claims carry a small tag:

| Tag | Meaning |
|-----|---------|
| ✅ | Verified against a primary source (official docs) |
| 💡 | Inference / teaching analogy built on verified facts |
| ⚠️ | Flagged — true but with a caveat worth knowing |

---

## TABLE OF CONTENTS

1. [The One-Sentence Version](#1-the-one-sentence-version)
2. [The Big Idea: The Index at the Back of a Book](#2-the-big-idea-the-index-at-the-back-of-a-book)
3. [The Vocabulary (Mapped to Things You Already Know)](#3-the-vocabulary-mapped-to-things-you-already-know)
4. [Under the Hood: Lucene, Shards, and Replicas](#4-under-the-hood-lucene-shards-and-replicas)
5. [The Store → Retrieve Loop (High Level)](#5-the-store--retrieve-loop-high-level)
6. [Good-to-Know Facts](#6-good-to-know-facts)
7. [When to Use It (and When Not To)](#7-when-to-use-it-and-when-not-to)
8. [Verification Record](#8-verification-record)
9. [Sources & Cross-References](#9-sources--cross-references)
10. [Revision History](#10-revision-history)

---

## 1. The One-Sentence Version
[TYPE: CONTEXT]

Elasticsearch is a program whose whole job is to **store piles of data and then find the
right pieces of it almost instantly** — especially text. ✅ *(Official: "a distributed,
RESTful search engine" — Elastic.)*

A normal database is great at answering "give me the row with `id = 42`." Elasticsearch is
built for the harder question: "out of ten million records, which ones are *most relevant*
to the words I just typed?" — and it answers that in milliseconds. 💡

One quick naming note: people sometimes say "Elastic DB" or just "Elastic." The actual
product is called **Elasticsearch**, and it's the core of the wider **Elastic Stack** (also
called the ELK Stack: Elasticsearch + Logstash + Kibana). ✅ This document is about
Elasticsearch itself.

---

## 2. The Big Idea: The Index at the Back of a Book
[TYPE: CONTEXT]

This is the single most important idea, so we'll spend a moment on it.

Imagine a 1,000-page book and you want every page that mentions "dragon." The slow way is to
read all 1,000 pages. The fast way is to flip to the **index at the back**, where someone has
already listed: *dragon → pages 42, 87, 203*. You jump straight there. 💡

Elasticsearch works exactly like that book index. When you give it text, it doesn't keep the
text as one big blob and re-read it on every search. Instead it builds an **inverted index**:
a list that maps each *word* to *the documents that contain it.* ✅ *(Official Apache Lucene
docs define this as an "inverted index" — it lists, for a term, the documents that contain
it, the inverse of documents listing their words.)*

```
  Your documents:                 The inverted index Elasticsearch builds:
  ┌───────────────────────┐
  │ Doc 1: "winter is here"│        winter  → Doc 1
  │ Doc 2: "fire and ice"  │   ⇒    is      → Doc 1
  │ Doc 3: "ice is cold"   │        here    → Doc 1
  └───────────────────────┘        fire    → Doc 2
                                    and     → Doc 2
                                    ice     → Doc 2, Doc 3
                                    cold    → Doc 3
```

Now a search for "ice" doesn't scan anything — it just looks up the word and instantly sees
"Doc 2 and Doc 3." ✅ *(Elastic's own "Bottom Up" guide builds the inverted index this exact
way.)* **That lookup-not-scan trick is the reason Elasticsearch is fast.** 💡

---

## 3. The Vocabulary (Mapped to Things You Already Know)
[TYPE: REFERENCE]

Elasticsearch borrows ideas from regular databases but uses different words. Here is the
translation. ✅ *(Terms and structure per official Elastic documentation.)*

| Elasticsearch term | Plain meaning | Rough database equivalent |
|--------------------|---------------|---------------------------|
| **Document** | One record, written as JSON | A row |
| **Field** | One piece of a document (e.g. `title`) | A column |
| **Index** | A collection of similar documents | A table / database |
| **Mapping** | The "shape" of documents in an index (field names + types) | A schema (but flexible) |
| **Shard** | A slice of an index that holds part of the data | A partition |
| **Replica** | A spare copy of a shard | A backup copy |
| **Node** | One running Elasticsearch server | A server |
| **Cluster** | A group of nodes working together | A server farm |

A document looks like this — just plain JSON: ✅

```json
{
  "title": "Intro to Elasticsearch",
  "author": "Sam",
  "tags": ["search", "beginner"],
  "published": "2026-06-27"
}
```

> ⚠️ **The word "index" is overloaded — this trips up every beginner.** It means two
> different things: (a) the *collection of documents* you store data in, and (b) the
> *inverted index* data structure from Section 2 that makes search fast. Context tells you
> which one is meant. ✅

---

## 4. Under the Hood: Lucene, Shards, and Replicas
[TYPE: REFERENCE]

### 4.1 Lucene is the real engine

Elasticsearch doesn't build the search machinery from scratch. Underneath, it uses a Java
library called **Apache Lucene**, which is what actually creates the inverted index and ranks
results. ✅ *(Official: Elasticsearch is "built on Apache Lucene.")* The simplest way to think
about it: **Lucene is the search engine; Elasticsearch wraps many Lucene engines in a
distributed system with a friendly REST API, copies for safety, and cluster management.** 💡

### 4.2 Why split an index into shards

A single index might be too big for one server, so Elasticsearch chops it into **shards**, and
spreads them across nodes. ✅ Here's the key technical fact: **each shard is itself a complete,
self-contained Lucene index.** ✅ *(Elastic + JVM Advent: an Elasticsearch shard corresponds to
a Lucene index.)* So an Elasticsearch index is really "a bunch of Lucene indexes glued
together." 💡

When you save a document, Elasticsearch decides which shard it belongs to using a simple
formula — roughly `shard = hash(document_id) % number_of_primary_shards`. ✅ Two consequences
worth remembering:

- The same `id` always lands on the same shard, so it can be found again. 💡
- ⚠️ **You choose the number of primary shards when you create the index, and it's fixed after
  that** — because the routing math depends on that count. ✅ *(Standard documented behavior;
  corroborated across multiple sources.)*

### 4.3 Replicas = safety + extra speed

A **replica** is a copy of a shard kept on a *different* node. If a node dies, the replica
takes over, so you don't lose data. ✅ Bonus: replicas can also answer searches, so they add
read capacity, not just backup. ✅ *(Elastic + JVM Advent: replica shards can participate in
search queries, not only provide high availability.)*

```
  Cluster
  ├── Node A
  │   ├── Shard 0  (primary)   ← a Lucene index
  │   └── Shard 1  (replica)   ← copy of Shard 1
  └── Node B
      ├── Shard 1  (primary)   ← a Lucene index
      └── Shard 0  (replica)   ← copy of Shard 0
```

---

## 5. The Store → Retrieve Loop (High Level)
[TYPE: REFERENCE]

This is the heart of your question — *how a "file" (document) gets stored and retrieved.*
Here is the simple version. A future document will zoom into each step. 💡

### 5.1 Storing (indexing) a document

1. You send a JSON document to Elasticsearch over its REST API (an HTTP request). ✅
2. Elasticsearch picks the right shard for it (the routing formula from Section 4.2). ✅
3. The text is **analyzed** — broken into individual words/terms, usually lowercased and
   cleaned up (e.g. "Fire and ICE" → `fire`, `and`, `ice`). ✅ *(Elastic "Bottom Up": simple
   text processing — lowercasing, removing punctuation, splitting words — precedes the
   inverted index.)*
4. Those terms get added to the inverted index inside a **segment** (more on segments in
   Section 6). ✅
5. The document becomes searchable a moment later — by default within about **1 second.** ✅
   *(Official Elastic docs, "Near real-time search.")*

```
  [Your JSON] → REST API → pick shard → analyze into terms → write to a segment
                                                                   ↓
                                              searchable after the next refresh (~1s)
```

### 5.2 Retrieving (searching) for documents

1. You send a search request (e.g. "find documents about *ice*"). ✅
2. Your search words go through the **same analysis** as the stored text, so they match
   (e.g. "ICE" becomes `ice`). 💡 *(Inference: matching only works because store-time and
   query-time analysis agree.)*
3. Elasticsearch looks each term up in the inverted index — no full scan. ✅
4. It **scores** each matching document for relevance and returns them **ranked best-first.**
   ✅ The default scoring algorithm is **BM25**, which broadly rewards rarer query words and
   documents where the words appear more often, while not letting very long documents win
   just by being long. ✅ *(Official Elastic "Similarity settings": BM25 is the built-in
   similarity; defaults `k1 = 1.2`, `b = 0.75`.)*
5. You get back JSON results, each with a `_score`. ✅

```
  [Search words] → analyze → look up terms in inverted index → score with BM25 → ranked results
```

> 💡 **The symmetry is the whole trick:** the same analysis is applied both when storing and
> when searching, so the words always line up. Store turns text into an index; search reads
> that index back.

---

## 6. Good-to-Know Facts
[TYPE: REFERENCE]

A few facts that explain a lot of Elasticsearch's behavior:

- **It speaks JSON over HTTP.** You can think of Elasticsearch as a server that takes JSON
  requests and gives back JSON answers. ✅
- **Segments are immutable.** New documents are written into new little files called
  *segments*, which are never edited in place. ✅ *(Apache Lucene docs + Elastic.)*
  - A **delete** just *marks* a document as deleted; the data is physically removed later. ✅
  - An **update** is really a delete-plus-add. ✅
  - In the background, small segments are **merged** into bigger ones to keep search fast. ✅
- **Search is "near-real-time," not instant.** Because a new document is only searchable after
  the next *refresh*, there's a tiny delay (≈1 second by default). ✅ *(Official Elastic docs.)*
- **It is not your primary database — by design choice.** Lucene/Elasticsearch is a search
  layer; a common, safe pattern is to keep your source-of-truth data in a regular database and
  use Elasticsearch for searching over it. ⚠️ *(Widely recommended practice, not a hard
  technical rule — Elasticsearch can store data, but teams often pair it with a primary
  store.)*
- **Current version:** Elasticsearch **9.4.2**, released **28 May 2026.** ✅ *(Official Elastic
  download page.)* The fundamentals above are stable and apply across recent versions. 💡

---

## 7. When to Use It (and When Not To)
[TYPE: REFERENCE]

To stay balanced, here is the honest two-sided view. 💡

**Great fit for:**
- Full-text search (search bars, site search, product catalogs). ✅
- Log and event analysis, dashboards, and metrics (the classic ELK use case). ✅
- Finding "most relevant" results, not just exact matches. ✅

**Think twice when:**
- You mainly need strict transactions, joins, and guaranteed immediate consistency — that's a
  relational database's strength, not Elasticsearch's. ⚠️ *(General trade-off; Elasticsearch
  favors search speed and scale over relational-style transactions.)*
- You need a document to be searchable the very instant it's written — remember the ~1s
  near-real-time delay. ✅

---

## 8. Verification Record
[TYPE: REFERENCE]

```
VERIFICATION RECORD
═══════════════════════════════════════════════════════════
Task:    Beginner primer — "How does Elasticsearch work (basics)"
Mode:    MEDIUM-HIGH (technical documentation)
Session: 2026-06-27

VERIFIED CLAIMS (✅): core concepts confirmed against Tier 1 sources
  ✅ Built on Apache Lucene — Elastic official + Lucene official docs
  ✅ Inverted index maps terms → documents — Apache Lucene official docs
  ✅ Index → shards; each shard is a Lucene index — Elastic blog / docs
  ✅ Routing ≈ hash(id) % primary_shard_count; count fixed at creation — standard documented behavior
  ✅ Replicas give HA and also serve searches — Elastic / corroborated
  ✅ Segments are immutable; delete = mark, update = delete+add; merges run in background — Lucene / Elastic
  ✅ Near-real-time, default refresh ≈1s — Elastic official "Near real-time search"
  ✅ BM25 is default similarity; defaults k1=1.2, b=0.75 — Elastic official "Similarity settings"
  ✅ Current version 9.4.2, released 2026-05-28 — Elastic official download page

INFERENCE / ANALOGY (💡): teaching devices built on the verified facts above
  (book-index analogy, "Lucene is the engine" framing, store/search symmetry)

FLAGGED (⚠️): true-with-caveat
  ⚠️ "Not your primary database" is a recommended pattern, not a hard rule
  ⚠️ Primary-shard count being fixed: sourced from Tier 3 pages but is canonical, well-known behavior

OUTLIERS ANALYSED: 0 (no source contradicted the mainstream technical account)
REMOVED: 0   |   BOGUS CAUGHT: 0   |   UNRESOLVED: 0
TIER 4 SOURCES EXCLUDED: all (none used)
INDUSTRY-FUNDED SOURCES: Elastic publishes docs about its own product — used only for
  factual product behavior (version, defaults, mechanics), which is the authoritative source
  for those facts; no competitive/benchmark claims were drawn from it.
OVERALL CONFIDENCE: High      GAPS DISCLOSED: Yes (depth deferred to future docs)
═══════════════════════════════════════════════════════════
```

---

## 9. Sources & Cross-References
[TYPE: REFERENCE]

### 9.1 Sources & References

**Primary Research (Tier 1 — official vendor / library documentation)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| Elastic | Near real-time search (refresh ≈1s) | current | https://www.elastic.co/docs/manage-data/data-store/near-real-time-search |
| Elastic | Similarity settings (BM25 default; k1=1.2, b=0.75) | current | https://www.elastic.co/docs/reference/elasticsearch/index-settings/similarity |
| Elastic | Download Elasticsearch (v9.4.2, 2026-05-28) | 2026 | https://www.elastic.co/downloads/elasticsearch |
| Apache Lucene | Index File Formats (definition of inverted index) | — | https://lucene.apache.org/core/3_0_3/fileformats.html |
| Elastic | Elasticsearch from the Bottom Up, Part 1 | 2024 | https://www.elastic.co/blog/found-elasticsearch-from-the-bottom-up |
| Elastic | Practical BM25, Part 2 | 2024 | https://www.elastic.co/blog/practical-bm25-part-2-the-bm25-algorithm-and-its-variables |

**Secondary Research (Tier 3 — corroboration only, flagged where used)**

| Source | Title | Date | URL |
|--------|-------|------|-----|
| JVM Advent | Elasticsearch Internals | 2022 | https://www.javaadvent.com/2022/12/elasticsearch-internals.html |

**Further Reading**

- Elastic Blog — "Elasticsearch from the Bottom Up" series (continues into distributed search).
- Apache Lucene documentation — for the lowest-level mechanics of segments and postings.

### 9.2 Document Cross-References

| Relationship | Document | Reason |
|--------------|----------|--------|
| [DEPENDS_ON] | 000 Elasticsearch — How It Works (Master Index) [planned] | This is a child of that master |
| [SEE_ALSO] → | 011 Elasticsearch-Vocabulary-By-Example | Worked example (3 PDFs) that makes Sections 3 & 5 concrete |
| [EXTENDS] → | 020 Elasticsearch-How-Storage-Works | Section 5.1 is the teaser this expands into full internals |
| [EXTENDS] → | 030 Elasticsearch-How-Retrieval-Works | Section 5.2 is the teaser this expands into the full search path |
| [SEE_ALSO] → | 040 Elasticsearch-Semantic-RAG-and-MCP | Applied/advanced layer: semantic search, RAG, the MCP server, multi-format ingestion |

> **Bidirectional note:** When `000`, `020`, and `030` are created, add the reciprocal
> reference back to this document (`010`) in each, per Documentation Standards rule 16.

---

## 10. Revision History

| Version | Date | Change Type | System Version | Description | Reason |
|---------|------|-------------|----------------|-------------|--------|
| 1.0 | 2026-06-27 | Initial | Elasticsearch 9.4.2 | First version — beginner primer on Elasticsearch fundamentals | Requested foundation document before storage/retrieval deep-dives |
| 1.1 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Added bidirectional [SEE_ALSO] reference to new child doc 011 | Child worked-example created; reciprocal reference required by Documentation Standards rule 16 |
| 1.2 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Marked child doc 020 (storage deep-dive) as created | Storage deep-dive authored; reciprocal reference required by rule 16 |
| 1.3 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Marked child doc 030 (retrieval deep-dive) as created | Retrieval deep-dive authored; reciprocal reference required by rule 16 |
| 1.4 | 2026-06-27 | Update | Elasticsearch 9.4.2 | Added [SEE_ALSO] reference to new doc 040 (semantic/RAG/MCP) | Applied/advanced doc authored; reciprocal reference required by rule 16 |

---

*Template: TMPL-002 Technical Reference v1.0 (adapted for a beginner primer) | Parent: 000 Elasticsearch — How It Works (planned)*
